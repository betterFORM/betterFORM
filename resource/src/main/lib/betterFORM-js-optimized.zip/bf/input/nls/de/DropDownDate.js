//>>built
define(
"bf/input/nls/de/DropDownDate", //begin v1.x content
    ({
        january:"Januar",
        february:"Februar",
        march:"März",
        april:"April",
        may:"Mai",
        june:"Juni",
        july:"Juli",
        august:"August",
        september:"September",
        october:"Oktober",
        november:"November",
        december:"Dezember"
    })
//end v1.x content
);
