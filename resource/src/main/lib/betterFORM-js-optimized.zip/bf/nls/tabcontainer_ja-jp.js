require({cache:{
'dijit/nls/ja/loading':function(){
define(
"dijit/nls/ja/loading", //begin v1.x content
({
	loadingState: "ロード中...",
	errorState: "エラーが発生しました。"
})
//end v1.x content
);

},
'dijit/nls/ja-jp/loading':function(){
define('dijit/nls/ja-jp/loading',{});
},
'dijit/nls/ja/common':function(){
define(
"dijit/nls/ja/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "キャンセル",
	buttonSave: "保存",
	itemClose: "閉じる"
})
//end v1.x content
);

},
'dijit/nls/ja-jp/common':function(){
define('dijit/nls/ja-jp/common',{});
}}});
define("bf/nls/tabcontainer_ja-jp", [], 1);
