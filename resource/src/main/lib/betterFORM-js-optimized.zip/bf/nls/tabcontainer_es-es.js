require({cache:{
'dijit/nls/es/loading':function(){
define(
"dijit/nls/es/loading", //begin v1.x content
({
	loadingState: "Cargando...",
	errorState: "Lo siento, se ha producido un error"
})
//end v1.x content
);

},
'dijit/nls/es-es/loading':function(){
define('dijit/nls/es-es/loading',{});
},
'dijit/nls/es/common':function(){
define(
"dijit/nls/es/common", //begin v1.x content
({
	buttonOk: "Aceptar",
	buttonCancel: "Cancelar",
	buttonSave: "Guardar",
	itemClose: "Cerrar"
})
//end v1.x content
);

},
'dijit/nls/es-es/common':function(){
define('dijit/nls/es-es/common',{});
}}});
define("bf/nls/tabcontainer_es-es", [], 1);
