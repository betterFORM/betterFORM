require({cache:{
'dijit/form/nls/sl/ComboBox':function(){
define(
"dijit/form/nls/sl/ComboBox", //begin v1.x content
({
		previousMessage: "Prejšnje izbire",
		nextMessage: "Dodatne izbire"
})

//end v1.x content
);

},
'dijit/form/nls/sl/validate':function(){
define(
"dijit/form/nls/sl/validate", //begin v1.x content
({
	invalidMessage: "Vnesena vrednost ni veljavna.",
	missingMessage: "Ta vrednost je zahtevana.",
	rangeMessage: "Ta vrednost je izven območja."
})

//end v1.x content
);

},
'bf/input/nls/sl/DropDownDate':function(){
define('bf/input/nls/sl/DropDownDate',{});
}}});
define("bf/nls/dates_sl", [], 1);
