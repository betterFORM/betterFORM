require({cache:{
'dojo/cldr/nls/it/number':function(){
define(
"dojo/cldr/nls/it/number", //begin v1.x content
{
	"decimalFormat": "#,##0.###",
	"group": ".",
	"scientificFormat": "#E0",
	"percentFormat": "#,##0%",
	"currencyFormat": "¤ #,##0.00",
	"decimal": ","
}
//end v1.x content
);
},
'dojo/cldr/nls/it-it/number':function(){
define('dojo/cldr/nls/it-it/number',{});
}}});
define("bf/nls/slider_it-it", [], 1);
