require({cache:{
'dijit/form/nls/de/ComboBox':function(){
define(
"dijit/form/nls/de/ComboBox", //begin v1.x content
({
		previousMessage: "Vorherige Auswahl",
		nextMessage: "Weitere Auswahlmöglichkeiten"
})
//end v1.x content
);

},
'dijit/form/nls/de-de/ComboBox':function(){
define('dijit/form/nls/de-de/ComboBox',{});
},
'dijit/form/nls/de/validate':function(){
define(
"dijit/form/nls/de/validate", //begin v1.x content
({
	invalidMessage: "Der eingegebene Wert ist ungültig. ",
	missingMessage: "Dieser Wert ist erforderlich.",
	rangeMessage: "Dieser Wert liegt außerhalb des gültigen Bereichs. "
})
//end v1.x content
);

},
'dijit/form/nls/de-de/validate':function(){
define('dijit/form/nls/de-de/validate',{});
},
'bf/input/nls/de/DropDownDate':function(){
define(
"bf/input/nls/de/DropDownDate", //begin v1.x content
    ({
        january:"Januar",
        february:"Februar",
        march:"März",
        april:"April",
        may:"Mai",
        june:"Juni",
        july:"Juli",
        august:"August",
        september:"September",
        october:"Oktober",
        november:"November",
        december:"Dezember"
    })
//end v1.x content
);

},
'bf/input/nls/de-de/DropDownDate':function(){
define('bf/input/nls/de-de/DropDownDate',{});
}}});
define("bf/nls/dates_de-de", [], 1);
