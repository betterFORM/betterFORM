require({cache:{
'dijit/form/nls/hu/ComboBox':function(){
define(
"dijit/form/nls/hu/ComboBox", //begin v1.x content
({
		previousMessage: "Előző menüpontok",
		nextMessage: "További menüpontok"
})
//end v1.x content
);

},
'dijit/form/nls/hu/validate':function(){
define(
"dijit/form/nls/hu/validate", //begin v1.x content
({
	invalidMessage: "A megadott érték érvénytelen.",
	missingMessage: "Meg kell adni egy értéket.",
	rangeMessage: "Az érték kívül van a megengedett tartományon."
})
//end v1.x content
);

},
'bf/input/nls/hu/DropDownDate':function(){
define('bf/input/nls/hu/DropDownDate',{});
}}});
define("bf/nls/dates_hu", [], 1);
