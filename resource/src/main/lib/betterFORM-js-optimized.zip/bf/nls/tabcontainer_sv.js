require({cache:{
'dijit/nls/sv/loading':function(){
define(
"dijit/nls/sv/loading", //begin v1.x content
({
	loadingState: "Läser in...",
	errorState: "Det uppstod ett fel."
})
//end v1.x content
);

},
'dijit/nls/sv/common':function(){
define(
"dijit/nls/sv/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Avbryt",
	buttonSave: "Spara",
	itemClose: "Stäng"
})
//end v1.x content
);

}}});
define("bf/nls/tabcontainer_sv", [], 1);
