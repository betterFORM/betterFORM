require({cache:{
'dijit/form/nls/tr/validate':function(){
define(
"dijit/form/nls/tr/validate", //begin v1.x content
({
	invalidMessage: "Girilen değer geçersiz.",
	missingMessage: "Bu değer gerekli.",
	rangeMessage: "Bu değer aralık dışında."
})
//end v1.x content
);

},
'bf/input/nls/tr/DropDownDate':function(){
define('bf/input/nls/tr/DropDownDate',{});
},
'dijit/nls/tr/loading':function(){
define(
"dijit/nls/tr/loading", //begin v1.x content
({
	loadingState: "Yükleniyor...",
	errorState: "Üzgünüz, bir hata oluştu"
})
//end v1.x content
);

},
'dojo/cldr/nls/tr/number':function(){
define(
"dojo/cldr/nls/tr/number", //begin v1.x content
{
	"group": ".",
	"percentSign": "%",
	"exponential": "E",
	"scientificFormat": "#E0",
	"percentFormat": "% #,##0",
	"list": ";",
	"infinity": "∞",
	"patternDigit": "#",
	"minusSign": "-",
	"decimal": ",",
	"nan": "NaN",
	"nativeZeroDigit": "0",
	"perMille": "‰",
	"decimalFormat": "#,##0.###",
	"currencyFormat": "#,##0.00 ¤",
	"plusSign": "+"
}
//end v1.x content
);
},
'dijit/form/nls/tr/ComboBox':function(){
define(
"dijit/form/nls/tr/ComboBox", //begin v1.x content
({
		previousMessage: "Önceki seçenekler",
		nextMessage: "Diğer seçenekler"
})
//end v1.x content
);

},
'dijit/nls/tr/common':function(){
define(
"dijit/nls/tr/common", //begin v1.x content
({
	buttonOk: "Tamam",
	buttonCancel: "İptal",
	buttonSave: "Kaydet",
	itemClose: "Kapat"
})
//end v1.x content
);

}}});
define("bf/nls/bfRelease_tr", [], 1);
