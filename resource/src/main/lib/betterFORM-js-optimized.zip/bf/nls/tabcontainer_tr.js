require({cache:{
'dijit/nls/tr/loading':function(){
define(
"dijit/nls/tr/loading", //begin v1.x content
({
	loadingState: "Yükleniyor...",
	errorState: "Üzgünüz, bir hata oluştu"
})
//end v1.x content
);

},
'dijit/nls/tr/common':function(){
define(
"dijit/nls/tr/common", //begin v1.x content
({
	buttonOk: "Tamam",
	buttonCancel: "İptal",
	buttonSave: "Kaydet",
	itemClose: "Kapat"
})
//end v1.x content
);

}}});
define("bf/nls/tabcontainer_tr", [], 1);
