//>>built
define(
"dojo/cldr/nls/cs/currency", //begin v1.x content
{
	"HKD_displayName": "Dolar hongkongský",
	"CHF_displayName": "Frank švýcarský",
	"CAD_displayName": "Dolar kanadský",
	"CNY_displayName": "Juan renminbi",
	"AUD_displayName": "Dolar australský",
	"JPY_displayName": "Jen",
	"USD_displayName": "Dolar americký",
	"GBP_displayName": "Libra šterlinků",
	"EUR_displayName": "Euro"
}
//end v1.x content
);