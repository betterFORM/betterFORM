
{
	"USD_symbol": "US$",
	"CAD_symbol": "CA$",
	"GBP_symbol": "£",
	"HKD_symbol": "HK$",
	"JPY_symbol": "JP¥",
	"AUD_symbol": "AU$",
	"CNY_symbol": "CN¥",
	"EUR_symbol": "€"
}
