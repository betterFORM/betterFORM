
{
	"currencyFormat": "#,##0.00 ¤",
	"group": " "
}
