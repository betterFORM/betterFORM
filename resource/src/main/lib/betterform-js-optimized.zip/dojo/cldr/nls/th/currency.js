
{
	"HKD_displayName": "ดอลลาร์ฮ่องกง",
	"CHF_displayName": "ฟรังก์สวิส",
	"JPY_symbol": "¥",
	"CAD_displayName": "ดอลลาร์แคนาดา",
	"CNY_displayName": "หยวนเหรินหมินปี้ (สาธารณรัฐประชาชนจีน)",
	"AUD_displayName": "ดอลลาร์ออสเตรเลีย",
	"JPY_displayName": "เยนญี่ปุ่น",
	"USD_displayName": "ดอลลาร์สหรัฐ",
	"GBP_displayName": "ปอนด์สเตอร์ลิง (สหราชอาณาจักร)",
	"EUR_displayName": "ยูโร"
}
