//>>built
define(
"dojo/cldr/nls/en-gb/islamic", //begin v1.x content
{
	"dateFormat-medium": "d MMM y G",
	"dateFormatItem-MMMEd": "E d MMM",
	"dateFormatItem-MMdd": "dd/MM",
	"dateFormatItem-MEd": "E, d/M",
	"dateFormatItem-yMEd": "EEE, d/M/yyyy",
	"dateFormatItem-yyyyMMM": "MMM y G",
	"eraNarrow": [
		"AH"
	],
	"months-format-narrow": [
		"1",
		"2",
		"3",
		"4",
		"5",
		"6",
		"7",
		"8",
		"9",
		"10",
		"11",
		"12"
	],
	"dateFormatItem-yyMMM": "MMM y G",
	"dateFormatItem-Md": "d/M",
	"months-standAlone-narrow": [
		"1",
		"2",
		"3",
		"4",
		"5",
		"6",
		"7",
		"8",
		"9",
		"10",
		"11",
		"12"
	],
	"months-standAlone-wide": [
		"Muharram",
		"Safar",
		"Rabiʻ I",
		"Rabiʻ II",
		"Jumada I",
		"Jumada II",
		"Rajab",
		"Shaʻban",
		"Ramadan",
		"Shawwal",
		"Dhuʻl-Qiʻdah",
		"Dhuʻl-Hijjah"
	],
	"eraNames": [
		"AH"
	],
	"days-standAlone-narrow": [
		"S",
		"M",
		"T",
		"W",
		"T",
		"F",
		"S"
	],
	"dateFormatItem-yyyyMEd": "EEE, d/M/y G",
	"dateFormatItem-yyyyMMMM": "MMMM y G",
	"dateFormatItem-MMMMd": "d MMMM",
	"months-standAlone-abbr": [
		"Muh.",
		"Saf.",
		"Rab. I",
		"Rab. II",
		"Jum. I",
		"Jum. II",
		"Raj.",
		"Sha.",
		"Ram.",
		"Shaw.",
		"Dhuʻl-Q.",
		"Dhuʻl-H."
	],
	"dateFormatItem-yQQQ": "QQQ y",
	"dateFormatItem-yyyyMM": "MM/y G",
	"dateFormat-long": "d MMMM y G",
	"dateFormat-short": "dd/MM/y G",
	"dateFormatItem-yMMMEd": "EEE, MMM d, y",
	"months-format-wide": [
		"Muharram",
		"Safar",
		"Rabiʻ I",
		"Rabiʻ II",
		"Jumada I",
		"Jumada II",
		"Rajab",
		"Shaʻban",
		"Ramadan",
		"Shawwal",
		"Dhuʻl-Qiʻdah",
		"Dhuʻl-Hijjah"
	],
	"dateFormatItem-yM": "M/y",
	"months-format-abbr": [
		"Muh.",
		"Saf.",
		"Rab. I",
		"Rab. II",
		"Jum. I",
		"Jum. II",
		"Raj.",
		"Sha.",
		"Ram.",
		"Shaw.",
		"Dhuʻl-Q.",
		"Dhuʻl-H."
	],
	"eraAbbr": [
		"AH"
	],
	"days-format-wide": [
		"Sunday",
		"Monday",
		"Tuesday",
		"Wednesday",
		"Thursday",
		"Friday",
		"Saturday"
	],
	"dateFormatItem-yQ": "Q y",
	"dateFormatItem-yMMM": "MMM y",
	"quarters-format-wide": [
		"1st quarter",
		"2nd quarter",
		"3rd quarter",
		"4th quarter"
	],
	"dateFormatItem-yyyyMd": "d/M/y G",
	"dateFormat-full": "EEEE, d MMMM y G",
	"days-format-abbr": [
		"Sun",
		"Mon",
		"Tue",
		"Wed",
		"Thu",
		"Fri",
		"Sat"
	]
}
//end v1.x content
);