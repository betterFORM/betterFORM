
{
	"HKD_displayName": "港元",
	"CHF_displayName": "瑞士法郎",
	"CAD_displayName": "加拿大元",
	"CNY_displayName": "人民币",
	"AUD_displayName": "澳大利亚元",
	"JPY_displayName": "日元",
	"USD_displayName": "美元",
	"CNY_symbol": "￥",
	"GBP_displayName": "英镑",
	"EUR_displayName": "欧元"
}
