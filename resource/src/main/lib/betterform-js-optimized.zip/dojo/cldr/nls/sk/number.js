//>>built
define(
"dojo/cldr/nls/sk/number", //begin v1.x content
{
	"currencyFormat": "#,##0.00 ¤",
	"group": " ",
	"decimal": ","
}
//end v1.x content
);