
{
	"AUD_symbol": "$",
	"USD_symbol": "US$"
}
