
{
	"currencyFormat": "¤#,##0.00"
}
