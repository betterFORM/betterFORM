
{
	"USD_symbol": "$",
	"EUR_displayName": "歐元",
	"HKD_displayName": "港幣",
	"CAD_displayName": "加幣",
	"JPY_displayName": "日圓",
	"GBP_displayName": "英鎊",
	"AUD_displayName": "澳幣",
	"CNY_displayName": "人民幣"
}
