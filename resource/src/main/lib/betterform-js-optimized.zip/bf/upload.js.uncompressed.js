//>>built
require({cache:{
'url:bf/upload/Upload.html':"<div>\n    <input type=\"file\" value=\"\" class=\"xfValue\" data-dojo-attach-point=\"inputNode\" name=\"${name}\"  />\n    <div class=\"bfProgressbar\" style=\"display:none;\" data-dojo-attach-point=\"progress\">\n        <div class=\"border\">\n            <div data-dojo-attach-point=\"progressBackground\" class=\"background\"></div>\n        </div>\n    </div>\n    <input  type=\"hidden\" value=\"\" data-dojo-attach-point=\"fileName\" />\n    <iframe  src=\"\" style=\"width:0px;height:0px;border:0\"></iframe>\n</div>\n",
'bf/upload/Upload':function(){
require({cache:{
'url:bf/upload/Upload.html':"<div>\n    <input type=\"file\" value=\"\" class=\"xfValue\" data-dojo-attach-point=\"inputNode\" name=\"${name}\"  />\n    <div class=\"bfProgressbar\" style=\"display:none;\" data-dojo-attach-point=\"progress\">\n        <div class=\"border\">\n            <div data-dojo-attach-point=\"progressBackground\" class=\"background\"></div>\n        </div>\n    </div>\n    <input  type=\"hidden\" value=\"\" data-dojo-attach-point=\"fileName\" />\n    <iframe  src=\"\" style=\"width:0px;height:0px;border:0\"></iframe>\n</div>\n"}});
/*
 * Copyright (c) 2012. betterFORM Project - http://www.betterform.de
 * Licensed under the terms of BSD License
 */

define("bf/upload/Upload", ["dojo/_base/declare",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dojo/text!./Upload.html",
    "dojo/on",
    "dojo/query",
    "dojo/dom-attr",
    "dojo/dom-style",
    "dojo/_base/lang",
    "dojo/_base/fx"],
    function(declare, _Widget, TemplatedMixin, template, on, query, domAttr, domStyle, lang, fx){
        return declare([_Widget,TemplatedMixin], {

            // parameters
            value:"",
            templateString:template,
            disabledNodes: new Array(),
            progress: null,
            progressBackground: null,
            fileId:"",
            fileValue:"",
            progressUpdate:null,
            name:'',
            xfControlId:'',

            postMixInProperties:function() {
                this.inherited(arguments);
            },

            postCreate:function() {
                this.inherited(arguments);

                on(this.inputNode,"change", lang.hitch(this, "confirm"));

                /*
                // console.debug("Upload.postMixInProperties: START this", this);
                this.inherited(arguments);
                var uploadName = domAttr(this.srcNodeRef, "name");
                var uploadFileId = domAttr(this.srcNodeRef, "fileId");
                var uploadFileValue = domAttr(this.srcNodeRef, "fileValue");
                if(uploadFileId == undefined || uploadFileId == ""){
                    uploadName = fluxProcessor.dataPrefix + this.xfControlId;
                }
                //console.debug("uploadName: ",uploadName, " uploadFileId:",uploadFileId, " uploadFileValue:",uploadFileValue);
                domAttr(this.inputNode, "name", uploadName);
                domAttr(this.fileName, "id", uploadFileId);
                domAttr(this.fileName, "value", uploadFileValue);
                dojo.removeClass(this.domNode, "xfValue");
                  */
            },

            confirm: function() {
                var action = confirm("Really upload ?");
                if (action) {
                    this._submitFile();
                }
                else {
                    this.inputNode.value = "";
                }
            },

            _submitFile: function() {
                // console.debug("UploadPlain._submitFile");

                // disable all controls contained in repeat prototypes to avoid
                // inconsistent updates.
                var me = this.inputNode;
                query(".xfUpload.xfReadWrite .xfValue").forEach(function(item) {
                    if(item != me){
                        //console.debug("Disable Upload Item: ", item);
                        domAttr.set(item, "disabled", "disabled");
                    }
                });


/* Effect.BlindDown(this.xformsId + "-progress"); */
                domStyle.set(this.progress, 'display', 'block');
                domStyle.set(this.progress, 'opacity', '1');


                var path = this.inputNode.value;
                var filename = path.substring(path.lastIndexOf("/") + 1);
                // console.debug("Upload: npath: ", path, " filename:", filename);
                //polling betterForm for update information and submit the form

                //this.progressHandle = connect.subscribe("upload-progress-event-"+ this.xfControlId, this, "updateProgress");
                this.progressUpdate = setInterval("fluxProcessor.fetchProgress('" + this.xfControlId + "','" + filename + "')", 500);

                document.forms["betterform"].target = "UploadTarget";
                document.forms["betterform"].submit();
                return true;
            },

            updateProgress: function (value) {
                // console.debug("UploadPlain.updateProgress: value",value);
                if (value != 0) {
                    domStyle.set(this.progressBackground,"width",value + "%");
                }
                if (value < 0) {
                    alert("Upload failed");
                }
                if (value == 100) {
                    // stop polling
                    // console.debug("UploadPlain.updateProgress before Clear Interval");
                    clearInterval(this.progressUpdate);
                    // console.debug("stopped polling");
                    domStyle.set(this.progressBackground,"width","100%");


                    fx.fadeOut({
                        node: this.progress,
                        duration:2000,
                        onEnd: dojo.hitch(this,function() {
                            domStyle.set(this.progress, 'display', 'none');

                        })
                    }).play();
                }



                    // reset disabled controls

                    query(".xfUpload.xfReadWrite .xfValue:disabled").forEach(function(item) {
                        domAttr.remove(item, "disabled");
                    });




            }



        });
});



/*
 _onFocus:function() {
 this.inherited(arguments);
 this.handleOnFocus();
 },
 */



/*           onChange: function() {
 // console.debug("UploadPlain.onChange");
 var action = confirm("Really upload ?");
 if (action) {
 //this._submitFile(this.inputNode);
 }
 else {
 this.inputNode.value = "";
 }
 },
 */
/*
 */
},
'bf/factory/FactoryUpload':function(){
define("bf/factory/FactoryUpload", ["dojo/_base/declare","dojo/_base/connect","dijit/registry","dojo/dom-attr", "bf/util"],
    function(declare,connect,registry,domAttr) {
        return declare(null,
            {
                /**
                 *
                 * @param type
                 * @param node
                 */
                create:function(type, node){
//                    var xfControlDijit = registry.byId(xfId);
                    require(["dojo/query"],function(query){
                        var n = query("> .xfValue",node)[0];
                        var xfId = bf.util.getXfId(n);

                        switch(type){

                            case "fileUpload":
                            case "base64binary":
                            case "hexBinary":
                                // console.warn("FactoryUpload.[file|base64|hex]");
                                require(["bf/upload/Upload"], function(Upload) {
                                    // console.debug("upload created: ",xfId);
                                    uploadWidget = new Upload({
                                        xfControlId : xfId,
                                        name:domAttr.get(n,'name')
                                    },n);
                                });
                                break;
                            default:
                                console.warn("FactoryUpload.default");
                        }
                    });
                }

            }
        );
    }
);


}}});

require(["dojo/i18n"], function(i18n){
i18n._preloadLocalizations("bf/nls/upload", []);
});
define("bf/upload", [], 1);
