require({cache:{
'dijit/nls/ko/loading':function(){
define(
"dijit/nls/ko/loading", //begin v1.x content
({
	loadingState: "로드 중...",
	errorState: "죄송합니다. 오류가 발생했습니다."
})
//end v1.x content
);

},
'dijit/nls/ko-kr/loading':function(){
define('dijit/nls/ko-kr/loading',{});
},
'dijit/nls/ko/common':function(){
define(
"dijit/nls/ko/common", //begin v1.x content
({
	buttonOk: "확인",
	buttonCancel: "취소",
	buttonSave: "저장",
	itemClose: "닫기"
})
//end v1.x content
);

},
'dijit/nls/ko-kr/common':function(){
define('dijit/nls/ko-kr/common',{});
}}});
define("bf/nls/dashboard_ko-kr", [], 1);
