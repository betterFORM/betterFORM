require({cache:{
'dijit/nls/sk/loading':function(){
define(
"dijit/nls/sk/loading", //begin v1.x content
({
	loadingState: "Zavádzanie...",
	errorState: "Nastala chyba"
})

//end v1.x content
);

},
'dijit/nls/sk/common':function(){
define(
"dijit/nls/sk/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Zrušiť",
	buttonSave: "Uložiť",
	itemClose: "Zatvoriť"
})

//end v1.x content
);

}}});
define("bf/nls/tabcontainer_sk", [], 1);
