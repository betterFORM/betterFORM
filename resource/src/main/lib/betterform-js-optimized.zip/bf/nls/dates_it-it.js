require({cache:{
'dijit/form/nls/it/ComboBox':function(){
define(
"dijit/form/nls/it/ComboBox", //begin v1.x content
({
		previousMessage: "Scelte precedenti",
		nextMessage: "Altre scelte"
})
//end v1.x content
);

},
'dijit/form/nls/it-it/ComboBox':function(){
define('dijit/form/nls/it-it/ComboBox',{});
},
'dijit/form/nls/it/validate':function(){
define(
"dijit/form/nls/it/validate", //begin v1.x content
({
	invalidMessage: "Il valore immesso non è valido.",
	missingMessage: "Questo valore è obbligatorio.",
	rangeMessage: "Questo valore non è compreso nell'intervallo."
})
//end v1.x content
);

},
'dijit/form/nls/it-it/validate':function(){
define('dijit/form/nls/it-it/validate',{});
},
'bf/input/nls/it/DropDownDate':function(){
define('bf/input/nls/it/DropDownDate',{});
},
'bf/input/nls/it-it/DropDownDate':function(){
define('bf/input/nls/it-it/DropDownDate',{});
}}});
define("bf/nls/dates_it-it", [], 1);
