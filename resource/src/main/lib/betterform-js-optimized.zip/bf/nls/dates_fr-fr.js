require({cache:{
'dijit/form/nls/fr/ComboBox':function(){
define(
"dijit/form/nls/fr/ComboBox", //begin v1.x content
({
		previousMessage: "Choix précédents",
		nextMessage: "Plus de choix"
})
//end v1.x content
);

},
'dijit/form/nls/fr-fr/ComboBox':function(){
define('dijit/form/nls/fr-fr/ComboBox',{});
},
'dijit/form/nls/fr/validate':function(){
define(
"dijit/form/nls/fr/validate", //begin v1.x content
({
	invalidMessage: "La valeur indiquée n'est pas correcte.",
	missingMessage: "Cette valeur est requise.",
	rangeMessage: "Cette valeur n'est pas comprise dans la plage autorisée."
})
//end v1.x content
);

},
'dijit/form/nls/fr-fr/validate':function(){
define('dijit/form/nls/fr-fr/validate',{});
},
'bf/input/nls/fr/DropDownDate':function(){
define('bf/input/nls/fr/DropDownDate',{});
},
'bf/input/nls/fr-fr/DropDownDate':function(){
define('bf/input/nls/fr-fr/DropDownDate',{});
}}});
define("bf/nls/dates_fr-fr", [], 1);
