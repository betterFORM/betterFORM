require({cache:{
'dijit/nls/th/loading':function(){
define(
"dijit/nls/th/loading", //begin v1.x content
({
	loadingState: "กำลังโหลด...",
	errorState: "ขออภัย เกิดข้อผิดพลาด"
})

//end v1.x content
);

},
'dijit/nls/th/common':function(){
define(
"dijit/nls/th/common", //begin v1.x content
({
	buttonOk: "ตกลง",
	buttonCancel: "ยกเลิก",
	buttonSave: "บันทึก",
	itemClose: "ปิด"
})

//end v1.x content
);

}}});
define("bf/nls/dashboard_th", [], 1);
