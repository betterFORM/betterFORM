require({cache:{
'dijit/nls/cs/loading':function(){
define(
"dijit/nls/cs/loading", //begin v1.x content
({
	loadingState: "Probíhá načítání...",
	errorState: "Omlouváme se, došlo k chybě"
})
//end v1.x content
);

},
'dijit/nls/cs/common':function(){
define(
"dijit/nls/cs/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Storno",
	buttonSave: "Uložit",
	itemClose: "Zavřít"
})
//end v1.x content
);

}}});
define("bf/nls/tabcontainer_cs", [], 1);
