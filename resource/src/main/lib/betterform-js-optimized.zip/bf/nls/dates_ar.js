require({cache:{
'dijit/form/nls/ar/ComboBox':function(){
define(
"dijit/form/nls/ar/ComboBox", //begin v1.x content
({
		previousMessage: "الاختيارات السابقة",
		nextMessage: "مزيد من الاختيارات"
})
//end v1.x content
);

},
'dijit/form/nls/ar/validate':function(){
define(
"dijit/form/nls/ar/validate", //begin v1.x content
({
	invalidMessage: "القيمة التي تم ادخالها غير صحيحة.",
	missingMessage: "يجب ادخال هذه القيمة.",
	rangeMessage: "هذه القيمة ليس بالمدى الصحيح."
})
//end v1.x content
);

},
'bf/input/nls/ar/DropDownDate':function(){
define('bf/input/nls/ar/DropDownDate',{});
}}});
define("bf/nls/dates_ar", [], 1);
