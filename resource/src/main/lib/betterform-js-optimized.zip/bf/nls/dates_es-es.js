require({cache:{
'dijit/form/nls/es/ComboBox':function(){
define(
"dijit/form/nls/es/ComboBox", //begin v1.x content
({
		previousMessage: "Opciones anteriores",
		nextMessage: "Más opciones"
})
//end v1.x content
);

},
'dijit/form/nls/es-es/ComboBox':function(){
define('dijit/form/nls/es-es/ComboBox',{});
},
'dijit/form/nls/es/validate':function(){
define(
"dijit/form/nls/es/validate", //begin v1.x content
({
	invalidMessage: "El valor especificado no es válido.",
	missingMessage: "Este valor es necesario.",
	rangeMessage: "Este valor está fuera del intervalo."
})
//end v1.x content
);

},
'dijit/form/nls/es-es/validate':function(){
define('dijit/form/nls/es-es/validate',{});
},
'bf/input/nls/es/DropDownDate':function(){
define('bf/input/nls/es/DropDownDate',{});
},
'bf/input/nls/es-es/DropDownDate':function(){
define('bf/input/nls/es-es/DropDownDate',{});
}}});
define("bf/nls/dates_es-es", [], 1);
