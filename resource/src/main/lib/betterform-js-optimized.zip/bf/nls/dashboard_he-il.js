require({cache:{
'dijit/nls/he/loading':function(){
define(
"dijit/nls/he/loading", //begin v1.x content
({
	loadingState: "טעינה...‏",
	errorState: "אירעה שגיאה"
})
//end v1.x content
);

},
'dijit/nls/he-il/loading':function(){
define('dijit/nls/he-il/loading',{});
},
'dijit/nls/he/common':function(){
define(
"dijit/nls/he/common", //begin v1.x content
({
	buttonOk: "אישור",
	buttonCancel: "ביטול",
	buttonSave: "שמירה",
	itemClose: "סגירה"
})
//end v1.x content
);

},
'dijit/nls/he-il/common':function(){
define('dijit/nls/he-il/common',{});
}}});
define("bf/nls/dashboard_he-il", [], 1);
