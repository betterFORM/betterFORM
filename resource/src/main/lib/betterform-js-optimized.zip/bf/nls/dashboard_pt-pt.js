require({cache:{
'dijit/nls/pt/loading':function(){
define(
"dijit/nls/pt/loading", //begin v1.x content
({
	loadingState: "Carregando...",
	errorState: "Desculpe, ocorreu um erro"
})
//end v1.x content
);

},
'dijit/nls/pt-pt/loading':function(){
define(
"dijit/nls/pt-pt/loading", //begin v1.x content
({
	loadingState: "A carregar...",
	errorState: "Lamentamos, mas ocorreu um erro"
})
//end v1.x content
);

},
'dijit/nls/pt/common':function(){
define(
"dijit/nls/pt/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Cancelar",
	buttonSave: "Salvar",
	itemClose: "Fechar"
})
//end v1.x content
);

},
'dijit/nls/pt-pt/common':function(){
define(
"dijit/nls/pt-pt/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Cancelar",
	buttonSave: "Guardar",
	itemClose: "Fechar"
})
//end v1.x content
);

}}});
define("bf/nls/dashboard_pt-pt", [], 1);
