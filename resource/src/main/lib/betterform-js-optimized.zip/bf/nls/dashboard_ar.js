require({cache:{
'dijit/nls/ar/loading':function(){
define(
"dijit/nls/ar/loading", //begin v1.x content
({
	loadingState: "جاري التحميل...",
	errorState: "عفوا، حدث خطأ"
})
//end v1.x content
);

},
'dijit/nls/ar/common':function(){
define(
"dijit/nls/ar/common", //begin v1.x content
({
	buttonOk: "حسنا",
	buttonCancel: "الغاء",
	buttonSave: "حفظ",
	itemClose: "اغلاق"
})
//end v1.x content
);

}}});
define("bf/nls/dashboard_ar", [], 1);
