require({cache:{
'dijit/form/nls/pt/validate':function(){
define(
"dijit/form/nls/pt/validate", //begin v1.x content
({
	invalidMessage: "O valor inserido não é válido.",
	missingMessage: "Este valor é necessário.",
	rangeMessage: "Este valor está fora do intervalo. "
})
//end v1.x content
);

},
'dijit/form/nls/pt-br/validate':function(){
define('dijit/form/nls/pt-br/validate',{});
},
'bf/input/nls/pt/DropDownDate':function(){
define('bf/input/nls/pt/DropDownDate',{});
},
'bf/input/nls/pt-br/DropDownDate':function(){
define('bf/input/nls/pt-br/DropDownDate',{});
},
'dojo/cldr/nls/pt/gregorian':function(){
define(
"dojo/cldr/nls/pt/gregorian", //begin v1.x content
{
	"months-format-narrow": [
		"J",
		"F",
		"M",
		"A",
		"M",
		"J",
		"J",
		"A",
		"S",
		"O",
		"N",
		"D"
	],
	"field-weekday": "Dia da semana",
	"dateFormatItem-yQQQ": "y QQQ",
	"dateFormatItem-yMEd": "EEE, dd/MM/yyyy",
	"dateFormatItem-MMMEd": "EEE, d 'de' MMM",
	"eraNarrow": [
		"a.C.",
		"d.C."
	],
	"dayPeriods-format-wide-morning": "manhã",
	"dateFormat-long": "d 'de' MMMM 'de' y",
	"months-format-wide": [
		"janeiro",
		"fevereiro",
		"março",
		"abril",
		"maio",
		"junho",
		"julho",
		"agosto",
		"setembro",
		"outubro",
		"novembro",
		"dezembro"
	],
	"dateFormatItem-EEEd": "EEE, d",
	"dateFormat-full": "EEEE, d 'de' MMMM 'de' y",
	"dateFormatItem-Md": "d/M",
	"dayPeriods-format-wide-noon": "meio-dia",
	"field-era": "Era",
	"dateFormatItem-yM": "MM/yyyy",
	"months-standAlone-wide": [
		"janeiro",
		"fevereiro",
		"março",
		"abril",
		"maio",
		"junho",
		"julho",
		"agosto",
		"setembro",
		"outubro",
		"novembro",
		"dezembro"
	],
	"timeFormat-short": "HH:mm",
	"quarters-format-wide": [
		"1º trimestre",
		"2º trimestre",
		"3º trimestre",
		"4º trimestre"
	],
	"timeFormat-long": "HH'h'mm'min'ss's' z",
	"field-year": "Ano",
	"dateFormatItem-yMMM": "MMM 'de' y",
	"dateFormatItem-yQ": "yyyy Q",
	"field-hour": "Hora",
	"dateFormatItem-MMdd": "dd/MM",
	"months-format-abbr": [
		"jan",
		"fev",
		"mar",
		"abr",
		"mai",
		"jun",
		"jul",
		"ago",
		"set",
		"out",
		"nov",
		"dez"
	],
	"dateFormatItem-yyQ": "Q yy",
	"timeFormat-full": "HH'h'mm'min'ss's' zzzz",
	"field-day-relative+0": "Hoje",
	"field-day-relative+1": "Amanhã",
	"field-day-relative+2": "Depois de amanhã",
	"field-day-relative+3": "Daqui a três dias",
	"months-standAlone-abbr": [
		"jan",
		"fev",
		"mar",
		"abr",
		"mai",
		"jun",
		"jul",
		"ago",
		"set",
		"out",
		"nov",
		"dez"
	],
	"quarters-format-abbr": [
		"T1",
		"T2",
		"T3",
		"T4"
	],
	"quarters-standAlone-wide": [
		"1º trimestre",
		"2º trimestre",
		"3º trimestre",
		"4º trimestre"
	],
	"dateFormatItem-HHmmss": "HH'h'mm'min'ss's'",
	"dateFormatItem-M": "L",
	"days-standAlone-wide": [
		"domingo",
		"segunda-feira",
		"terça-feira",
		"quarta-feira",
		"quinta-feira",
		"sexta-feira",
		"sábado"
	],
	"dateFormatItem-yyyyMMM": "MMM 'de' y",
	"dateFormatItem-yyMMMEEEd": "EEE, d 'de' MMM 'de' yy",
	"dateFormatItem-yyMMM": "MMM 'de' yy",
	"timeFormat-medium": "HH:mm:ss",
	"dateFormatItem-Hm": "HH'h'mm",
	"quarters-standAlone-abbr": [
		"T1",
		"T2",
		"T3",
		"T4"
	],
	"eraAbbr": [
		"a.C.",
		"d.C."
	],
	"field-minute": "Minuto",
	"field-dayperiod": "Período do dia",
	"days-standAlone-abbr": [
		"dom",
		"seg",
		"ter",
		"qua",
		"qui",
		"sex",
		"sáb"
	],
	"dayPeriods-format-wide-night": "noite",
	"dateFormatItem-yyMMMd": "d 'de' MMM 'de' yy",
	"dateFormatItem-d": "d",
	"dateFormatItem-ms": "mm'min'ss's'",
	"field-day-relative+-1": "Ontem",
	"field-day-relative+-2": "Anteontem",
	"field-day-relative+-3": "Há três dias",
	"dateFormatItem-MMMd": "d 'de' MMM",
	"dateFormatItem-MEd": "EEE, dd/MM",
	"field-day": "Dia",
	"days-format-wide": [
		"domingo",
		"segunda-feira",
		"terça-feira",
		"quarta-feira",
		"quinta-feira",
		"sexta-feira",
		"sábado"
	],
	"field-zone": "Fuso",
	"dateFormatItem-yyyyMM": "MM/yyyy",
	"dateFormatItem-y": "y",
	"months-standAlone-narrow": [
		"J",
		"F",
		"M",
		"A",
		"M",
		"J",
		"J",
		"A",
		"S",
		"O",
		"N",
		"D"
	],
	"dateFormatItem-yyMM": "MM/yy",
	"days-format-abbr": [
		"dom",
		"seg",
		"ter",
		"qua",
		"qui",
		"sex",
		"sáb"
	],
	"eraNames": [
		"Antes de Cristo",
		"Ano do Senhor"
	],
	"days-format-narrow": [
		"D",
		"S",
		"T",
		"Q",
		"Q",
		"S",
		"S"
	],
	"field-month": "Mês",
	"days-standAlone-narrow": [
		"D",
		"S",
		"T",
		"Q",
		"Q",
		"S",
		"S"
	],
	"dateFormatItem-MMM": "LLL",
	"dateFormatItem-HHmm": "HH'h'mm",
	"dateFormat-short": "dd/MM/yy",
	"dayPeriods-format-wide-afternoon": "tarde",
	"field-second": "Segundo",
	"dateFormatItem-yMMMEd": "EEE, d 'de' MMM 'de' y",
	"field-week": "Semana",
	"dateFormat-medium": "dd/MM/yyyy"
}
//end v1.x content
);
},
'dojo/cldr/nls/pt-br/gregorian':function(){
define('dojo/cldr/nls/pt-br/gregorian',{});
},
'dijit/nls/pt/loading':function(){
define(
"dijit/nls/pt/loading", //begin v1.x content
({
	loadingState: "Carregando...",
	errorState: "Desculpe, ocorreu um erro"
})
//end v1.x content
);

},
'dijit/nls/pt-br/loading':function(){
define('dijit/nls/pt-br/loading',{});
},
'dojo/cldr/nls/pt/number':function(){
define(
"dojo/cldr/nls/pt/number", //begin v1.x content
{
	"group": ".",
	"percentSign": "%",
	"exponential": "E",
	"scientificFormat": "#E0",
	"percentFormat": "#,##0%",
	"list": ";",
	"infinity": "∞",
	"patternDigit": "#",
	"minusSign": "-",
	"decimal": ",",
	"nan": "NaN",
	"nativeZeroDigit": "0",
	"perMille": "‰",
	"decimalFormat": "#,##0.###",
	"currencyFormat": "¤#,##0.00;(¤#,##0.00)",
	"plusSign": "+"
}
//end v1.x content
);
},
'dojo/cldr/nls/pt-br/number':function(){
define('dojo/cldr/nls/pt-br/number',{});
},
'dijit/form/nls/pt/ComboBox':function(){
define(
"dijit/form/nls/pt/ComboBox", //begin v1.x content
({
		previousMessage: "Opções anteriores",
		nextMessage: "Mais opções"
})
//end v1.x content
);

},
'dijit/form/nls/pt-br/ComboBox':function(){
define('dijit/form/nls/pt-br/ComboBox',{});
},
'dijit/nls/pt/common':function(){
define(
"dijit/nls/pt/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Cancelar",
	buttonSave: "Salvar",
	itemClose: "Fechar"
})
//end v1.x content
);

},
'dijit/nls/pt-br/common':function(){
define('dijit/nls/pt-br/common',{});
}}});
define("bf/nls/bfRelease_pt-br", [], 1);
