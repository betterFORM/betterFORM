require({cache:{
'dijit/nls/en/loading':function(){
define('dijit/nls/en/loading',{});
},
'dijit/nls/en-gb/loading':function(){
define('dijit/nls/en-gb/loading',{});
},
'dijit/nls/en/common':function(){
define('dijit/nls/en/common',{});
},
'dijit/nls/en-gb/common':function(){
define('dijit/nls/en-gb/common',{});
}}});
define("bf/nls/dashboard_en-gb", [], 1);
