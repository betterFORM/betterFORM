require({cache:{
'dijit/form/nls/he/ComboBox':function(){
define(
"dijit/form/nls/he/ComboBox", //begin v1.x content
({
		previousMessage: "האפשרויות הקודמות",
		nextMessage: "אפשרויות נוספות"
})
//end v1.x content
);

},
'dijit/form/nls/he-il/ComboBox':function(){
define('dijit/form/nls/he-il/ComboBox',{});
},
'dijit/form/nls/he/validate':function(){
define(
"dijit/form/nls/he/validate", //begin v1.x content
({
	invalidMessage: "הערך שצוין אינו חוקי.",
	missingMessage: "זהו ערך דרוש.",
	rangeMessage: "הערך מחוץ לטווח."
})
//end v1.x content
);

},
'dijit/form/nls/he-il/validate':function(){
define('dijit/form/nls/he-il/validate',{});
},
'bf/input/nls/he/DropDownDate':function(){
define('bf/input/nls/he/DropDownDate',{});
},
'bf/input/nls/he-il/DropDownDate':function(){
define('bf/input/nls/he-il/DropDownDate',{});
}}});
define("bf/nls/dates_he-il", [], 1);
