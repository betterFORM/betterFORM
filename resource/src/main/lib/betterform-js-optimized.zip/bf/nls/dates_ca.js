require({cache:{
'dijit/form/nls/ca/ComboBox':function(){
define(
"dijit/form/nls/ca/ComboBox", //begin v1.x content
({
		previousMessage: "Opcions anteriors",
		nextMessage: "Més opcions"
})

//end v1.x content
);

},
'dijit/form/nls/ca/validate':function(){
define(
"dijit/form/nls/ca/validate", //begin v1.x content
({
	invalidMessage: "El valor introduït no és vàlid",
	missingMessage: "Aquest valor és necessari",
	rangeMessage: "Aquest valor és fora de l'interval"
})

//end v1.x content
);

},
'bf/input/nls/ca/DropDownDate':function(){
define('bf/input/nls/ca/DropDownDate',{});
}}});
define("bf/nls/dates_ca", [], 1);
