require({cache:{
'dijit/nls/el/loading':function(){
define(
"dijit/nls/el/loading", //begin v1.x content
({
	loadingState: "Φόρτωση...",
	errorState: "Σας ζητούμε συγνώμη, παρουσιάστηκε σφάλμα"
})
//end v1.x content
);

},
'dijit/nls/el/common':function(){
define(
"dijit/nls/el/common", //begin v1.x content
({
	buttonOk: "ΟΚ",
	buttonCancel: "Ακύρωση",
	buttonSave: "Αποθήκευση",
	itemClose: "Κλείσιμο"
})
//end v1.x content
);

}}});
define("bf/nls/tabcontainer_el", [], 1);
