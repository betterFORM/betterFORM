require({cache:{
'dijit/nls/it/loading':function(){
define(
"dijit/nls/it/loading", //begin v1.x content
({
	loadingState: "Caricamento in corso...",
	errorState: "Si è verificato un errore"
})
//end v1.x content
);

},
'dijit/nls/it-it/loading':function(){
define('dijit/nls/it-it/loading',{});
},
'dijit/nls/it/common':function(){
define(
"dijit/nls/it/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Annulla",
	buttonSave: "Salva",
	itemClose: "Chiudi"
})
//end v1.x content
);

},
'dijit/nls/it-it/common':function(){
define('dijit/nls/it-it/common',{});
}}});
define("bf/nls/tabcontainer_it-it", [], 1);
