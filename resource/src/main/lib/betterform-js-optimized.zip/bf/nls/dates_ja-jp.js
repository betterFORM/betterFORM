require({cache:{
'dijit/form/nls/ja/ComboBox':function(){
define(
"dijit/form/nls/ja/ComboBox", //begin v1.x content
({
		previousMessage: "以前の選択項目",
		nextMessage: "追加の選択項目"
})
//end v1.x content
);

},
'dijit/form/nls/ja-jp/ComboBox':function(){
define('dijit/form/nls/ja-jp/ComboBox',{});
},
'dijit/form/nls/ja/validate':function(){
define(
"dijit/form/nls/ja/validate", //begin v1.x content
({
	invalidMessage: "入力した値は無効です。",
	missingMessage: "この値は必須です。",
	rangeMessage: "この値は範囲外です。"
})
//end v1.x content
);

},
'dijit/form/nls/ja-jp/validate':function(){
define('dijit/form/nls/ja-jp/validate',{});
},
'bf/input/nls/ja/DropDownDate':function(){
define('bf/input/nls/ja/DropDownDate',{});
},
'bf/input/nls/ja-jp/DropDownDate':function(){
define('bf/input/nls/ja-jp/DropDownDate',{});
}}});
define("bf/nls/dates_ja-jp", [], 1);
