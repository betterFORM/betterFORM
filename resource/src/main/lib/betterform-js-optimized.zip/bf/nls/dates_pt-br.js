require({cache:{
'dijit/form/nls/pt/ComboBox':function(){
define(
"dijit/form/nls/pt/ComboBox", //begin v1.x content
({
		previousMessage: "Opções anteriores",
		nextMessage: "Mais opções"
})
//end v1.x content
);

},
'dijit/form/nls/pt-br/ComboBox':function(){
define('dijit/form/nls/pt-br/ComboBox',{});
},
'dijit/form/nls/pt/validate':function(){
define(
"dijit/form/nls/pt/validate", //begin v1.x content
({
	invalidMessage: "O valor inserido não é válido.",
	missingMessage: "Este valor é necessário.",
	rangeMessage: "Este valor está fora do intervalo. "
})
//end v1.x content
);

},
'dijit/form/nls/pt-br/validate':function(){
define('dijit/form/nls/pt-br/validate',{});
},
'bf/input/nls/pt/DropDownDate':function(){
define('bf/input/nls/pt/DropDownDate',{});
},
'bf/input/nls/pt-br/DropDownDate':function(){
define('bf/input/nls/pt-br/DropDownDate',{});
}}});
define("bf/nls/dates_pt-br", [], 1);
