require({cache:{
'dijit/nls/fr/loading':function(){
define(
"dijit/nls/fr/loading", //begin v1.x content
({
	loadingState: "Chargement...",
	errorState: "Une erreur est survenue"
})
//end v1.x content
);

},
'dijit/nls/fr-fr/loading':function(){
define('dijit/nls/fr-fr/loading',{});
},
'dijit/nls/fr/common':function(){
define(
"dijit/nls/fr/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Annuler",
	buttonSave: "Sauvegarder",
	itemClose: "Fermer"
})
//end v1.x content
);

},
'dijit/nls/fr-fr/common':function(){
define('dijit/nls/fr-fr/common',{});
}}});
define("bf/nls/tabcontainer_fr-fr", [], 1);
