require({cache:{
'dijit/form/nls/ko/ComboBox':function(){
define(
"dijit/form/nls/ko/ComboBox", //begin v1.x content
({
		previousMessage: "이전 선택사항",
		nextMessage: "기타 선택사항"
})
//end v1.x content
);

},
'dijit/form/nls/ko-kr/ComboBox':function(){
define('dijit/form/nls/ko-kr/ComboBox',{});
},
'dijit/form/nls/ko/validate':function(){
define(
"dijit/form/nls/ko/validate", //begin v1.x content
({
	invalidMessage: "입력된 값이 올바르지 않습니다.",
	missingMessage: "이 값은 필수입니다.",
	rangeMessage: "이 값은 범위를 벗어납니다."
})
//end v1.x content
);

},
'dijit/form/nls/ko-kr/validate':function(){
define('dijit/form/nls/ko-kr/validate',{});
},
'bf/input/nls/ko/DropDownDate':function(){
define('bf/input/nls/ko/DropDownDate',{});
},
'bf/input/nls/ko-kr/DropDownDate':function(){
define('bf/input/nls/ko-kr/DropDownDate',{});
}}});
define("bf/nls/dates_ko-kr", [], 1);
