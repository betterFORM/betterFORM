require({cache:{
'dojo/cldr/nls/ja/number':function(){
define(
"dojo/cldr/nls/ja/number", //begin v1.x content
{
	"decimalFormat": "#,##0.###",
	"group": ",",
	"scientificFormat": "#E0",
	"percentFormat": "#,##0%",
	"currencyFormat": "¤#,##0.00",
	"decimal": "."
}
//end v1.x content
);
},
'dojo/cldr/nls/ja-jp/number':function(){
define('dojo/cldr/nls/ja-jp/number',{});
}}});
define("bf/nls/slider_ja-jp", [], 1);
