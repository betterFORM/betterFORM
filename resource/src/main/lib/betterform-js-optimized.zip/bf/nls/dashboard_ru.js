require({cache:{
'dijit/nls/ru/loading':function(){
define(
"dijit/nls/ru/loading", //begin v1.x content
({
	loadingState: "Загрузка...",
	errorState: "Извините, возникла ошибка"
})
//end v1.x content
);

},
'dijit/nls/ru/common':function(){
define(
"dijit/nls/ru/common", //begin v1.x content
({
	buttonOk: "ОК",
	buttonCancel: "Отмена",
	buttonSave: "Сохранить",
	itemClose: "Закрыть"
})
//end v1.x content
);

}}});
define("bf/nls/dashboard_ru", [], 1);
