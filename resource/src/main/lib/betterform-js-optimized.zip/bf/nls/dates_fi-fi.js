require({cache:{
'dijit/form/nls/fi/ComboBox':function(){
define(
"dijit/form/nls/fi/ComboBox", //begin v1.x content
({
		previousMessage: "Edelliset valinnat",
		nextMessage: "Lisää valintoja"
})
//end v1.x content
);

},
'dijit/form/nls/fi-fi/ComboBox':function(){
define('dijit/form/nls/fi-fi/ComboBox',{});
},
'dijit/form/nls/fi/validate':function(){
define(
"dijit/form/nls/fi/validate", //begin v1.x content
({
	invalidMessage: "Annettu arvo ei kelpaa.",
	missingMessage: "Tämä arvo on pakollinen.",
	rangeMessage: "Tämä arvo on sallitun alueen ulkopuolella."
})
//end v1.x content
);

},
'dijit/form/nls/fi-fi/validate':function(){
define('dijit/form/nls/fi-fi/validate',{});
},
'bf/input/nls/fi/DropDownDate':function(){
define('bf/input/nls/fi/DropDownDate',{});
},
'bf/input/nls/fi-fi/DropDownDate':function(){
define('bf/input/nls/fi-fi/DropDownDate',{});
}}});
define("bf/nls/dates_fi-fi", [], 1);
