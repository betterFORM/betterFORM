require({cache:{
'dijit/nls/pl/loading':function(){
define(
"dijit/nls/pl/loading", //begin v1.x content
({
	loadingState: "Ładowanie...",
	errorState: "Niestety, wystąpił błąd"
})
//end v1.x content
);

},
'dijit/nls/pl/common':function(){
define(
"dijit/nls/pl/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Anuluj",
	buttonSave: "Zapisz",
	itemClose: "Zamknij"
})
//end v1.x content
);

}}});
define("bf/nls/tabcontainer_pl", [], 1);
