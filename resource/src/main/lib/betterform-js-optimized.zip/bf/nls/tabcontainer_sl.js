require({cache:{
'dijit/nls/sl/loading':function(){
define(
"dijit/nls/sl/loading", //begin v1.x content
({
	loadingState: "Nalaganje ...",
	errorState: "Oprostite, prišlo je do napake."
})
//end v1.x content
);

},
'dijit/nls/sl/common':function(){
define(
"dijit/nls/sl/common", //begin v1.x content
({
	buttonOk: "V redu",
	buttonCancel: "Prekliči",
	buttonSave: "Shrani",
	itemClose: "Zapri"
})

//end v1.x content
);

}}});
define("bf/nls/tabcontainer_sl", [], 1);
