require({cache:{
'dijit/nls/zh/loading':function(){
define(
"dijit/nls/zh/loading", //begin v1.x content
({
	loadingState: "正在加载...",
	errorState: "对不起，发生了错误"
})
//end v1.x content
);

},
'dijit/nls/zh-tw/loading':function(){
define(
"dijit/nls/zh-tw/loading", //begin v1.x content
({
	loadingState: "載入中...",
	errorState: "抱歉，發生錯誤"
})
//end v1.x content
);

},
'dijit/nls/zh/common':function(){
define(
"dijit/nls/zh/common", //begin v1.x content
({
	buttonOk: "确定",
	buttonCancel: "取消",
	buttonSave: "保存",
	itemClose: "关闭"
})
//end v1.x content
);

},
'dijit/nls/zh-tw/common':function(){
define(
"dijit/nls/zh-tw/common", //begin v1.x content
({
	buttonOk: "確定",
	buttonCancel: "取消",
	buttonSave: "儲存",
	itemClose: "關閉"
})
//end v1.x content
);

}}});
define("bf/nls/dashboard_zh-tw", [], 1);
