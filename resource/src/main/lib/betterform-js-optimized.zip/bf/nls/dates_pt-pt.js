require({cache:{
'dijit/form/nls/pt/ComboBox':function(){
define(
"dijit/form/nls/pt/ComboBox", //begin v1.x content
({
		previousMessage: "Opções anteriores",
		nextMessage: "Mais opções"
})
//end v1.x content
);

},
'dijit/form/nls/pt-pt/ComboBox':function(){
define(
"dijit/form/nls/pt-pt/ComboBox", //begin v1.x content
({
		previousMessage: "Opções anteriores",
		nextMessage: "Mais opções"
})
//end v1.x content
);

},
'dijit/form/nls/pt/validate':function(){
define(
"dijit/form/nls/pt/validate", //begin v1.x content
({
	invalidMessage: "O valor inserido não é válido.",
	missingMessage: "Este valor é necessário.",
	rangeMessage: "Este valor está fora do intervalo. "
})
//end v1.x content
);

},
'dijit/form/nls/pt-pt/validate':function(){
define(
"dijit/form/nls/pt-pt/validate", //begin v1.x content
({
	invalidMessage: "O valor introduzido não é válido.",
	missingMessage: "Este valor é requerido.",
	rangeMessage: "Este valor encontra-se fora do intervalo."
})
//end v1.x content
);

},
'bf/input/nls/pt/DropDownDate':function(){
define('bf/input/nls/pt/DropDownDate',{});
},
'bf/input/nls/pt-pt/DropDownDate':function(){
define('bf/input/nls/pt-pt/DropDownDate',{});
}}});
define("bf/nls/dates_pt-pt", [], 1);
