require({cache:{
'dijit/nls/en/loading':function(){
define('dijit/nls/en/loading',{});
},
'dijit/nls/en-us/loading':function(){
define('dijit/nls/en-us/loading',{});
},
'dijit/nls/en/common':function(){
define('dijit/nls/en/common',{});
},
'dijit/nls/en-us/common':function(){
define('dijit/nls/en-us/common',{});
}}});
define("bf/nls/dashboard_en-us", [], 1);
