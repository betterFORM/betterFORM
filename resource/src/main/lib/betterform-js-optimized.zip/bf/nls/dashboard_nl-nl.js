require({cache:{
'dijit/nls/nl/loading':function(){
define(
"dijit/nls/nl/loading", //begin v1.x content
({
	loadingState: "Bezig met laden...",
	errorState: "Er is een fout opgetreden"
})
//end v1.x content
);

},
'dijit/nls/nl-nl/loading':function(){
define('dijit/nls/nl-nl/loading',{});
},
'dijit/nls/nl/common':function(){
define(
"dijit/nls/nl/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Annuleren",
	buttonSave: "Opslaan",
	itemClose: "Sluiten"
})
//end v1.x content
);

},
'dijit/nls/nl-nl/common':function(){
define('dijit/nls/nl-nl/common',{});
}}});
define("bf/nls/dashboard_nl-nl", [], 1);
