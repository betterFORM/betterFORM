require({cache:{
'dijit/nls/da/loading':function(){
define(
"dijit/nls/da/loading", //begin v1.x content
({
	loadingState: "Indlæser...",
	errorState: "Der er opstået en fejl"
})
//end v1.x content
);

},
'dijit/nls/da/common':function(){
define(
"dijit/nls/da/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Annullér",
	buttonSave: "Gem",
	itemClose: "Luk"
})
//end v1.x content
);

}}});
define("bf/nls/tabcontainer_da", [], 1);
