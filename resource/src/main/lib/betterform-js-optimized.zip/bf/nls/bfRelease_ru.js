require({cache:{
'dijit/form/nls/ru/validate':function(){
define(
"dijit/form/nls/ru/validate", //begin v1.x content
({
	invalidMessage: "Указано недопустимое значение.",
	missingMessage: "Это обязательное значение.",
	rangeMessage: "Это значение вне диапазона."
})
//end v1.x content
);

},
'bf/input/nls/ru/DropDownDate':function(){
define('bf/input/nls/ru/DropDownDate',{});
},
'dijit/nls/ru/loading':function(){
define(
"dijit/nls/ru/loading", //begin v1.x content
({
	loadingState: "Загрузка...",
	errorState: "Извините, возникла ошибка"
})
//end v1.x content
);

},
'dojo/cldr/nls/ru/number':function(){
define(
"dojo/cldr/nls/ru/number", //begin v1.x content
{
	"group": " ",
	"percentSign": "%",
	"exponential": "E",
	"scientificFormat": "#E0",
	"percentFormat": "#,##0 %",
	"list": ";",
	"infinity": "∞",
	"patternDigit": "#",
	"minusSign": "-",
	"decimal": ",",
	"nativeZeroDigit": "0",
	"perMille": "‰",
	"decimalFormat": "#,##0.###",
	"currencyFormat": "#,##0.00 ¤",
	"plusSign": "+"
}
//end v1.x content
);
},
'dijit/form/nls/ru/ComboBox':function(){
define(
"dijit/form/nls/ru/ComboBox", //begin v1.x content
({
		previousMessage: "Предыдущие варианты",
		nextMessage: "Следующие варианты"
})
//end v1.x content
);

},
'dijit/nls/ru/common':function(){
define(
"dijit/nls/ru/common", //begin v1.x content
({
	buttonOk: "ОК",
	buttonCancel: "Отмена",
	buttonSave: "Сохранить",
	itemClose: "Закрыть"
})
//end v1.x content
);

}}});
define("bf/nls/bfRelease_ru", [], 1);
