require({cache:{
'dijit/nls/hu/loading':function(){
define(
"dijit/nls/hu/loading", //begin v1.x content
({
	loadingState: "Betöltés...",
	errorState: "Sajnálom, hiba történt"
})
//end v1.x content
);

},
'dijit/nls/hu/common':function(){
define(
"dijit/nls/hu/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Mégse",
	buttonSave: "Mentés",
	itemClose: "Bezárás"
})
//end v1.x content
);

}}});
define("bf/nls/dashboard_hu", [], 1);
