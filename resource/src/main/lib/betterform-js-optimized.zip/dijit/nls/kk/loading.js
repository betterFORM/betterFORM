
({
	loadingState: "Жүктелуде...",
	errorState: "Кешіріңіз, қате орын алды"
})
