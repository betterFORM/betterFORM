if(!dojo._hasResource["betterform.manifest"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["betterform.manifest"] = true;
/*
 * Copyright (c) 2012. betterFORM Project - http://www.betterform.de
 * Licensed under the terms of BSD License
 */

dojo.provide("betterform.manifest");
dojo.registerNamespaceResolver(function(name) {
  return "betterform.widgets.variousWidgets";
});

}
