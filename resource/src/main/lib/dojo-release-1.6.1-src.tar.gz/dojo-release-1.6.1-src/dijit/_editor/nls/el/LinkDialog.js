define(
//begin v1.x content
({
	createLinkTitle: "Ιδιότητες σύνδεσης",
	insertImageTitle: "Ιδιότητες εικόνας",
	url: "Διεύθυνση URL:",
	text: "Περιγραφή:",
	target: "Προορισμός:",
	set: "Ορισμός",
	currentWindow: "Τρέχον παράθυρο",
	parentWindow: "Γονικό παράθυρο",
	topWindow: "Παράθυρο σε πρώτο πλάνο",
	newWindow: "Νέο παράθυρο"
})

//end v1.x content
);
