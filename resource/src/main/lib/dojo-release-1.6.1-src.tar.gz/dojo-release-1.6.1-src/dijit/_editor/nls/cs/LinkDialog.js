define(
//begin v1.x content
({
	createLinkTitle: "Vlastnosti odkazu",
	insertImageTitle: "Vlastnosti obrázku",
	url: "Adresa URL:",
	text: "Popis:",
	target: "Cíl:",
	set: "Nastavit",
	currentWindow: "Aktuální okno",
	parentWindow: "Nadřízené okno",
	topWindow: "Okno nejvyšší úrovně",
	newWindow: "Nové okno"
})

//end v1.x content
);
