define(
//begin v1.x content
({
	createLinkTitle: "Pripojiť vlastnosti",
	insertImageTitle: "Vlastnosti obrázka ",
	url: "URL:",
	text: "Opis:",
	target: "Cieľ:",
	set: "Nastaviť",
	currentWindow: "Aktuálne okno ",
	parentWindow: "Rodičovské okno ",
	topWindow: "Najvrchnejšie okno ",
	newWindow: "Nové okno "
})

//end v1.x content
);
