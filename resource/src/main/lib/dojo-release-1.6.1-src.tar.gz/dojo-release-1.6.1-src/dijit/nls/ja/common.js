define(
//begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "キャンセル",
	buttonSave: "保存",
	itemClose: "閉じる"
})
//end v1.x content
);
