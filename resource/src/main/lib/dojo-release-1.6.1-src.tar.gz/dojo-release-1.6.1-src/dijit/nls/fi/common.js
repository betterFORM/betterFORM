define(
//begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Peruuta",
	buttonSave: "Tallenna",
	itemClose: "Sulje"
})
//end v1.x content
);
