define(
//begin v1.x content
({
	buttonOk: "확인",
	buttonCancel: "취소",
	buttonSave: "저장",
	itemClose: "닫기"
})
//end v1.x content
);
