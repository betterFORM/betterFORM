define(
//begin v1.x content
({
	loadingState: "جاري التحميل...",
	errorState: "عفوا، حدث خطأ"
})
//end v1.x content
);
