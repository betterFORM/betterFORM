define(
//begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Annuler",
	buttonSave: "Sauvegarder",
	itemClose: "Fermer"
})
//end v1.x content
);
