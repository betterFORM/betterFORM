define(
//begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Anuluj",
	buttonSave: "Zapisz",
	itemClose: "Zamknij"
})
//end v1.x content
);
