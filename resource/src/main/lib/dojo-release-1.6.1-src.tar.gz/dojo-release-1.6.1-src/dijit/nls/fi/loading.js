define(
//begin v1.x content
({
	loadingState: "Lataus on meneillään...",
	errorState: "On ilmennyt virhe."
})
//end v1.x content
);
