define(
//begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Болдырмау",
	buttonSave: "Сақтау",
	itemClose: "Жабу"
})
//end v1.x content
);
