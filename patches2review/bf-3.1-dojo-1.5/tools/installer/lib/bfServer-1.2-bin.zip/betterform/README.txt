+==========================================================================+
+==========================================================================+
+==============                                        ====================+
+==============    betterForm Project Quickstart Guide ====================+
+==============                                        ====================+
+==========================================================================+
+==========================================================================+


+--------------------------------------------------------------------------------------+
Minimal Requirements
+--------------------------------------------------------------------------------------+
   - JDK 1.5 or higher


+--------------------------------------------------------------------------------------+
Run betterFORM lightSteelBlue
+--------------------------------------------------------------------------------------+
Double click 'betterform.jar' to run betterFORM. If the betterFORM does not start make sure your system 
is configured to execute jar-files. 

Alternatively you can start betterFORM from a terminal. Switch to the installation directory and execute: 
  - java -Xms128m -Xmx512m -jar betterform.jar


+--------------------------------------------------------------------------------------+
Verify betterFORM lightSteelBlue Installation
+--------------------------------------------------------------------------------------+
After betterFORM is started open your browser and surf to: 
  - localhost:8080 to verify if the server started
  - http://localhost:8080/forms/status.xhtml to verify if XForms functionality is enabled


+--------------------------------------------------------------------------------------+
Browse & Deploy Forms
+--------------------------------------------------------------------------------------+
All XForms are located beneath $INSTALL_DIRECTORY/web/root/forms. Simply put your form (e.g. YourForm.xhtml)
underneath this folder and open it directly (http://localhost:8080/forms/YourForm.xhtml) or use the FormsBrowser 
at http://localhost:8080/jsp/forms.jsp to browse all available forms.


+--------------------------------------------------------------------------------------+
Further Information
+--------------------------------------------------------------------------------------+
For more detailed informations see
    - User Guide (web/src/main/webapp/doc/betterFormUserGuide)
    - Developer Guide (web/src/main/webapp/doc/betterFormDeveloperGuide)
    - Wiki (https://betterform.de/trac)
