dojo.provide('dojox.mdnd.tests.unitTests.dropIndicator.module');

try{
	doh.registerUrl("dojox.mdnd.tests.unitTests.dropIndicator.DropIndicatorTest",
			dojo.moduleUrl("dojox.mdnd","tests/unitTests/dropIndicator/DropIndicatorTest.html"), 60000);
}catch(e){
	doh.debug(e);
}
