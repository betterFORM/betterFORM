define(
//begin v1.x content
({
	insertAnchor: "Infoga ankare",
	title: "Egenskaper för ankare",
	anchor: "Namn:",
	text: "Beskrivning:",
	set: "Ange",
	cancel: "Avbryt"
})

//end v1.x content
);
