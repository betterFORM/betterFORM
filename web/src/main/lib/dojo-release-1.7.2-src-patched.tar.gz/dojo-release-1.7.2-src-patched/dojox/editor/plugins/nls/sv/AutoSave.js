define(
//begin v1.x content
({
	"saveLabel": "Spara",
	"saveSettingLabelOn": "Ange intervall för automatiskt sparande...",
	"saveSettingLabelOff": "Avaktivera automatiskt sparande",
	"saveSettingdialogTitle": "Spara automatiskt",
	"saveSettingdialogDescription": "Ange intervall för automatiskt sparande",
	"saveSettingdialogParamName": "Intervall för automatiskt sparande",
	"saveSettingdialogParamLabel": "min.",
	"saveSettingdialogButtonOk": "Ange intervall",
	"saveSettingdialogButtonCancel": "Avbryt",
	"saveMessageSuccess": "Sparades ${0}",
	"saveMessageFail": "Kunde inte sparas ${0}"
})

//end v1.x content
);
