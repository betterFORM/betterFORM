define(
//begin v1.x content
({
	insertEntity: "Symbol einfügen"
})

//end v1.x content
);
