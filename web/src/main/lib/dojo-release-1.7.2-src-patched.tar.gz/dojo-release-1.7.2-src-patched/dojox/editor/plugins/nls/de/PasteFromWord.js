define(
//begin v1.x content
({
	"pasteFromWord": "Aus Word einfügen",
	"paste": "Einfügen",
	"cancel": "Abbrechen",
	"instructions": "Fügt den Inhalt aus Word in das Textfeld unten ein. Wenn Sie mit dem einzufügenden Inhalt zufrieden sind, klicken Sie auf die Schaltfläche zum Einfügen. Um das Einfügen von Text abzubrechen, klicken Sie auf die Schaltfläche zum Abbrechen. "
})

//end v1.x content
);
