define(
//begin v1.x content
({
	insertAnchor: "Anker einfügen",
	title: "Eigenschaften des Ankers",
	anchor: "Name:",
	text: "Beschreibung:",
	set: "Festlegen",
	cancel: "Abbrechen"
})

//end v1.x content
);
