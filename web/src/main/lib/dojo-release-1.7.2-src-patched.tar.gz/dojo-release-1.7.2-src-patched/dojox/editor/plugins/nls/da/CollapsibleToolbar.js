define(
//begin v1.x content
({
	"collapse": "Skjul editorværktøjslinje",
	"expand": "Udvid editorværktøjslinje"
})

//end v1.x content
);
