define(
//begin v1.x content
({
	"collapse": "Editor-Symbolleiste ausblenden",
	"expand": "Editor-Symbolleiste einblenden"
})

//end v1.x content
);
