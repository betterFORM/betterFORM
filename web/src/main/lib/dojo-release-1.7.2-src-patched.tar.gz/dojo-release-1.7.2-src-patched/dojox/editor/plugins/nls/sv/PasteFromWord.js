define(
//begin v1.x content
({
	"pasteFromWord": "Klistra in från Word",
	"paste": "Klistra in",
	"cancel": "Avbryt",
	"instructions": "Klistra in innehållet från Word i textfältet nedan. När du är klar klickar du på Klistra in. Om du vill avbryta klickar du på Avbryt."
})

//end v1.x content
);
