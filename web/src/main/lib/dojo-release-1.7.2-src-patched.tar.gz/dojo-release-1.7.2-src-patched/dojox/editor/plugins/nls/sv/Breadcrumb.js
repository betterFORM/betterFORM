define(
//begin v1.x content
({
	"nodeActions": "${nodeName}-åtgärder",
	"selectContents": "Välj innehåll",
	"selectElement": "Välj element",
	"deleteElement": "Ta bort element",
	"deleteContents": "Ta bort innehåll",
	"moveStart": "Flytta markören till början",
	"moveEnd": "Flytta markören till slutet"
})

//end v1.x content
);
