define(
({
	"instructions": "Direkt inklistring är avaktiverat. Klistra in innehållet i det här fönstret med standardtangentkommandon eller inklistringsfunktionen på menyn. När du har valt innehåller klickar du på Klistra in. Avbryt om du inte vill klistra in innehållet. "
})
);
