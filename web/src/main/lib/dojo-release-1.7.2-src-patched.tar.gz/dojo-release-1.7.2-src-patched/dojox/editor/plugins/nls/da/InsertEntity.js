define(
//begin v1.x content
({
	insertEntity: "Indsæt symbol"
})

//end v1.x content
);
