define(
//begin v1.x content
({
	"save": "Speichern"
})

//end v1.x content
);
