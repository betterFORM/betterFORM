define(
//begin v1.x content
({
	"setButtonText": "Festlegen",
	"cancelButtonText": "Abbrechen"
})

//end v1.x content
);
