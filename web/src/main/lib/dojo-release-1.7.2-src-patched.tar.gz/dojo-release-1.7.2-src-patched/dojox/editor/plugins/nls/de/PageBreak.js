define(
//begin v1.x content
({
	"pageBreak": "Seitenumbruch"
})

//end v1.x content
);
