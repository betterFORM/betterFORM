define(
//begin v1.x content
({
	"blockquote": "Blockzitat"
})

//end v1.x content
);
