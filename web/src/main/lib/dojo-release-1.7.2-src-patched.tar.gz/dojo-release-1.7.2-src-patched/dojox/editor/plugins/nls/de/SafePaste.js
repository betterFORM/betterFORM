define(
({
	"instructions": "Direktes Einfügen ist inaktiviert. Fügen Sie Inhalte in diesen Dialog mithilfe der Standardsteuerelemente ein, die im Browser über die Tastatur oder über die Menüs zum Einfügen zur Verfügung stehen. Wenn der einzufügende Inhalt korrekt ist, drücken Sie die Einfügetaste. Zum Abbrechen der Einfügeoperation drücken Sie die Abbruchtaste."
})
);
