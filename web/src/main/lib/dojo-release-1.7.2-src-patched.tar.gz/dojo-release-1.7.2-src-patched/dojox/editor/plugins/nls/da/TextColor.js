define(
//begin v1.x content
({
	"setButtonText": "Definér",
	"cancelButtonText": "Annullér"
})

//end v1.x content
);
