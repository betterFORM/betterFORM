define(
//begin v1.x content
({
	"showBlockNodes": "HTML-Blockelemente anzeigen"
})

//end v1.x content
);
