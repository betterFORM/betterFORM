define(
//begin v1.x content
({
	"save": "Gem"
})

//end v1.x content
);
