define(
//begin v1.x content
({
	"pasteFromWord": "Sæt ind fra Word",
	"paste": "Sæt ind",
	"cancel": "Annullér",
	"instructions": "Indsæt indholdet fra Word i tekstfeltet nedenfor. Klik på knappen Sæt ind, når du er tilfreds med indholdet. Klik på knappen Annullér for at annullere indsættelse af tekst."
})

//end v1.x content
);
