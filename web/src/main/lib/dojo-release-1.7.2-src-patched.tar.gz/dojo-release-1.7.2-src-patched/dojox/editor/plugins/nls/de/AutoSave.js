define(
//begin v1.x content
({
	"saveLabel": "Speichern",
	"saveSettingLabelOn": "Intervall für automatisches Speichern festlegen",
	"saveSettingLabelOff": "Automatisches Speichern inaktivieren",
	"saveSettingdialogTitle": "Automatisch speichern",
	"saveSettingdialogDescription": "Intervall für automatisches Speichern angeben",
	"saveSettingdialogParamName": "Intervall für automatisches Speichern",
	"saveSettingdialogParamLabel": "Min.",
	"saveSettingdialogButtonOk": "Intervall festlegen",
	"saveSettingdialogButtonCancel": "Abbrechen",
	"saveMessageSuccess": "Gespeichert um ${0}",
	"saveMessageFail": "Konnte nicht um ${0} gespeichert werden"
})

//end v1.x content
);
