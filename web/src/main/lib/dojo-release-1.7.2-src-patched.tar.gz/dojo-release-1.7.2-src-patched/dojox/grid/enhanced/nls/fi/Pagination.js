define(
//begin v1.x content
({
	"descTemplate": "${2} - ${3} / ${1} ${0}",
	"firstTip": "Ensimmäinen sivu",
	"lastTip": "Viimeinen sivu",
	"nextTip": "Seuraava sivu",
	"prevTip": "Edellinen sivu",
	"itemTitle": "nimikkeet",
	"singularItemTitle": "kohde",
	"pageStepLabelTemplate": "Sivu ${0}",
	"pageSizeLabelTemplate": "${0} nimikettä sivua kohti",
	"allItemsLabelTemplate": "Kaikki nimikkeet",
	"gotoButtonTitle": "Siirry tietylle sivulle",
	"dialogTitle": "Siirry sivulle",
	"dialogIndication": "Kirjoita sivunumero",
	"pageCountIndication": " (${0} sivua)",
	"dialogConfirm": "Siirry",
	"dialogCancel": "Peruuta",
	"all": "kaikki"
})
//end v1.x content
);
