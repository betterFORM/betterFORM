define(
//begin v1.x content
({
	singleSort: "Einzelne Sortierung",
	nestedSort: "Verschachtelte Sortierung",
	ascending: "Aufsteigend",
	descending: "Absteigend",
	sortingState: "${0} - ${1}",
	unsorted: "Diese Spalte nicht sortieren",
	indirectSelectionRadio: "Zeile ${0}, einzelne Auswahl, Optionsfeld",
	indirectSelectionCheckBox: "Zeile ${0}, Mehrfachauswahl, Kontrollkästchen",
	selectAll: "Alles auswählen"
})
//end v1.x content
);

