define(
//begin v1.x content
({
	singleSort: "Classificação Única",
	nestedSort: "Classificação Aninhada",
	ascending: "Ascendente",
	descending: "Descendente",
	sortingState: "${0} - ${1}",
	unsorted: "Não classificar esta coluna",
	indirectSelectionRadio: "Linha ${0}, seleção única, botão de seleção",
	indirectSelectionCheckBox: "Linha ${0}, seleção múltipla, caixa de seleção",
	selectAll: "Selecionar todos"
})
//end v1.x content
);

