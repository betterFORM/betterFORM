define(
//begin v1.x content
({
	singleSort: "Простая сортировка",
	nestedSort: "Вложенная сортировка",
	ascending: "По возрастанию",
	descending: "По убыванию",
	sortingState: "${0} - ${1}",
	unsorted: "Не сортировать этот столбец",
	indirectSelectionRadio: "Строка ${0}, один выбор, радиокнопка",
	indirectSelectionCheckBox: "Строка ${0}, несколько выборов, переключатель",
	selectAll: "Выбрать все"
})
//end v1.x content
);

