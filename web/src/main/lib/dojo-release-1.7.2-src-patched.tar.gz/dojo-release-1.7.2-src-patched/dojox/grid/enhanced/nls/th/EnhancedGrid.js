define(
//begin v1.x content
({
	singleSort: "เรียงลำดับแบบเดี่ยว",
	nestedSort: "เรียงลำดับที่ซับซ้อน",
	ascending: "จากน้อยไปหามาก",
	descending: "จากมากไปหาน้อย",
	sortingState: "${0} - ${1}",
	unsorted: "ห้ามเรียงลำดับคอลัมน์นี้",
	indirectSelectionRadio: "แถว ${0}, การเลือกเดียว, กล่องวิทยุ",
	indirectSelectionCheckBox: "แถว ${0}, การเลือกจำนวนมาก, เช็กบ็อกซ์",
	selectAll: "เลือกทั้งหมด"
})
//end v1.x content
);

