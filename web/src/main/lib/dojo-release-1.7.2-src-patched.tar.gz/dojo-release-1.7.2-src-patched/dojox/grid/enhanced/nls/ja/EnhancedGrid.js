define(
//begin v1.x content
({
	singleSort: "単一ソート",
	nestedSort: "ネスト・ソート",
	ascending: "昇順",
	descending: "降順",
	sortingState: "${0} - ${1}",
	unsorted: "この列をソートしない",
	indirectSelectionRadio: "行 ${0}、単一選択、ラジオ・ボックス",
	indirectSelectionCheckBox: "行 ${0}、複数選択、チェック・ボックス",
	selectAll: "すべてを選択"
})
//end v1.x content
);
