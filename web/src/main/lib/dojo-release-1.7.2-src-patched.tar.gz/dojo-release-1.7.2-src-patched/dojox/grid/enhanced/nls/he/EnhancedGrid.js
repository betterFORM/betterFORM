define(
//begin v1.x content
({
	singleSort: "מיון יחיד",
	nestedSort: "מיון מקונן",
	ascending: "עולה",
	descending: "יורד",
	sortingState: "${0} - ${1}",
	unsorted: "אין למיין עמודה זו",
	indirectSelectionRadio: "שורה ${0}, בחירה יחידה, תיבת בחירה",
	indirectSelectionCheckBox: "שורה ${0}, בחירה מרובה, תיבת סימון",
	selectAll: "בחירת הכל"
})
//end v1.x content
);

