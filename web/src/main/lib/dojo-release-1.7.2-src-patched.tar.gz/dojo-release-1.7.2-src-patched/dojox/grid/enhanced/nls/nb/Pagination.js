define(
//begin v1.x content
({
	"descTemplate": "${2} - ${3} av ${1} ${0}",
	"firstTip": "Første side",
	"lastTip": "Siste side",
	"nextTip": "Neste side",
	"prevTip": "Forrige side",
	"itemTitle": "elementer",
	"singularItemTitle": "element",
	"pageStepLabelTemplate": "Side ${0}",
	"pageSizeLabelTemplate": "${0} elementer per side",
	"allItemsLabelTemplate": "Alle elementer",
	"gotoButtonTitle": "Gå til en bestemt side",
	"dialogTitle": "Gå til side",
	"dialogIndication": "Oppgi sidetallet",
	"pageCountIndication": " (${0} sider)",
	"dialogConfirm": "Utfør",
	"dialogCancel": "Avbryt",
	"all": "alle"
})
//end v1.x content
);
