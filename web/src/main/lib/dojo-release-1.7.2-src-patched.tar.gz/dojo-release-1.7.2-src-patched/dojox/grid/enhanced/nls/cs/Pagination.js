define(
//begin v1.x content
({
	"descTemplate": "${2} - ${3} z ${1} ${0}",
	"firstTip": "První stránka",
	"lastTip": "Poslední stránka",
	"nextTip": "Další stránka",
	"prevTip": "Předchozí stránka",
	"itemTitle": "položky",
	"singularItemTitle": "položka",
	"pageStepLabelTemplate": "Stránka ${0}",
	"pageSizeLabelTemplate": "${0} položek na stránku",
	"allItemsLabelTemplate": "Všechny položky",
	"gotoButtonTitle": "Přejít na specifickou stránku",
	"dialogTitle": "Přejít na stránku",
	"dialogIndication": "Uvést číslo stránky",
	"pageCountIndication": " (${0} stránky)",
	"dialogConfirm": "Přejít",
	"dialogCancel": "Storno",
	"all": "vše"
})
//end v1.x content
);

