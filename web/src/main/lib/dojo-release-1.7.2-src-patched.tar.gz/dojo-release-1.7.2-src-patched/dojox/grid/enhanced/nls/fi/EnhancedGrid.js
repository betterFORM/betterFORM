define(
//begin v1.x content
({
	singleSort: "Yksinkertainen lajittelu",
	nestedSort: "Sisäkkäinen lajittelu",
	ascending: "Nouseva",
	descending: "Laskeva",
	sortingState: "${0} - ${1}",
	unsorted: "Älä lajittele tätä saraketta",
	indirectSelectionRadio: "Rivi ${0}, yksittäisvalinta, ruutu",
	indirectSelectionCheckBox: "Rivi ${0}, monivalinta, valintaruutu",
	selectAll: "Valitse kaikki"
})
//end v1.x content
);

