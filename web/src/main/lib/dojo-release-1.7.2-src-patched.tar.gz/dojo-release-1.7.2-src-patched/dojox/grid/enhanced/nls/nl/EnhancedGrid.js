define(
//begin v1.x content
({
	singleSort: "Enkelvoudig sorteren",
	nestedSort: "Genest sorteren",
	ascending: "Oplopend",
	descending: "Aflopend",
	sortingState: "${0} - ${1}",
	unsorted: "Deze kolom niet sorteren",
	indirectSelectionRadio: "Rij ${0}, enkele selectie, keuzerondje",
	indirectSelectionCheckBox: "Rij ${0}, meerdere selecties, selectievakje",
	selectAll: "Alles selecteren"
})
//end v1.x content
);

