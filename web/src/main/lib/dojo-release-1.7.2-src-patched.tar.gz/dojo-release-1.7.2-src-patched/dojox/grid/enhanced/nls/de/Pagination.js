define(
//begin v1.x content
({
	"descTemplate": "${2} - ${3} von ${1} ${0}",
	"firstTip": "Erste Seite",
	"lastTip": "Letzte Seite",
	"nextTip": "Nächste Seite",
	"prevTip": "Vorherige Seite",
	"itemTitle": "Elemente",
	"singularItemTitle": "Element",
	"pageStepLabelTemplate": "Seite ${0}",
	"pageSizeLabelTemplate": "${0} Elemente pro Seite",
	"allItemsLabelTemplate": "Alle Elemente",
	"gotoButtonTitle": "Bestimmte Seite aufrufen",
	"dialogTitle": "Seite aufrufen",
	"dialogIndication": "Seitenzahl angeben",
	"pageCountIndication": " (${0} Seiten)",
	"dialogConfirm": "Start",
	"dialogCancel": "Abbrechen",
	"all": "alle"
})
//end v1.x content
);

