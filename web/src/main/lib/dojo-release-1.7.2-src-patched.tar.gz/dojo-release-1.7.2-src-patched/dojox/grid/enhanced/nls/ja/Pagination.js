define(
//begin v1.x content
({
	"descTemplate": "${2} - ${3}/${1} ${0}",
	"firstTip": "最初のページ",
	"lastTip": "最後のページ",
	"nextTip": "次のページ",
	"prevTip": "前のページ",
	"itemTitle": "項目",
	"singularItemTitle": "項目",
	"pageStepLabelTemplate": "ページ ${0}",
	"pageSizeLabelTemplate": "ページ当たり ${0} 項目",
	"allItemsLabelTemplate": "すべての項目",
	"gotoButtonTitle": "特定のページに移動",
	"dialogTitle": "ページの移動",
	"dialogIndication": "ページ番号を指定してください",
	"pageCountIndication": " (${0} ページ)",
	"dialogConfirm": "実行",
	"dialogCancel": "キャンセル",
	"all": "すべて"
})
//end v1.x content
);
