define(
//begin v1.x content
({
	singleSort: "Pojedyncze sortowanie",
	nestedSort: "Zagnieżdżone sortowanie",
	ascending: "Rosnąco",
	descending: "Malejąco",
	sortingState: "${0} - ${1}",
	unsorted: "Nie sortuj tej kolumny",
	indirectSelectionRadio: "Wiersz ${0}, pojedynczy wybór, zestaw przełączników",
	indirectSelectionCheckBox: "Wiersz ${0}, wybór wielokrotny, pole wyboru",
	selectAll: "Wybierz wszystko"
})
//end v1.x content
);

