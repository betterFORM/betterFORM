define(
//begin v1.x content
({
	"descTemplate": "${2} - ${3} z ${1} ${0}",
	"firstTip": "Pierwsza strona",
	"lastTip": "Ostatnia strona",
	"nextTip": "Następna strona",
	"prevTip": "Poprzednia strona",
	"itemTitle": "poz.",
	"singularItemTitle": "pozycja",
	"pageStepLabelTemplate": "Strona ${0}",
	"pageSizeLabelTemplate": "${0} poz. na stronę",
	"allItemsLabelTemplate": "Wszystkie pozycje",
	"gotoButtonTitle": "Idź do konkretnej strony",
	"dialogTitle": "Idź do strony",
	"dialogIndication": "Podaj numer strony",
	"pageCountIndication": " (${0} str.)",
	"dialogConfirm": "Wykonaj",
	"dialogCancel": "Anuluj",
	"all": "wszystkie"
})
//end v1.x content
);

