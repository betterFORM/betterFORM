define(
//begin v1.x content
({
	singleSort: "Tri simple",
	nestedSort: "Tri imbriqué",
	ascending: "Croissant",
	descending: "Décroissant",
	sortingState: "${0} - ${1}",
	unsorted: "Ne pas trier cette colonne",
	indirectSelectionRadio: "Ligne ${0}, sélection unique, bouton radio",
	indirectSelectionCheckBox: "Ligne ${0}, sélection multiple, case à cocher",
	selectAll: "Tout sélectionner"
})
//end v1.x content
);

