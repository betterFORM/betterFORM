define(
//begin v1.x content
({
	singleSort: "Ordre únic",
	nestedSort: "Ordre imbricat",
	ascending: "Ascendent",
	descending: "Descendent",
	sortingState: "${0} - ${1}",
	unsorted: "No ordenis aquesta finestra",
	indirectSelectionRadio: "Fila ${0}, selecció única, quadre d'opció",
	indirectSelectionCheckBox: "Fila ${0}, selecció múltiple, quadre de selecció",
	selectAll: "Seleccionar-ho tot"
})
//end v1.x content
);

