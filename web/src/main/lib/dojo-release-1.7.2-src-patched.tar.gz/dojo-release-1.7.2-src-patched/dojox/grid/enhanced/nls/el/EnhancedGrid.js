define(
//begin v1.x content
({
	singleSort: "Απλή ταξινόμηση",
	nestedSort: "Ένθετη ταξινόμηση",
	ascending: "Αύξουσα",
	descending: "Φθίνουσα",
	sortingState: "${0} - ${1}",
	unsorted: "Χωρίς ταξινόμηση αυτής της στήλης",
	indirectSelectionRadio: "Γραμμή ${0}, μονή επιλογή, κουμπί επιλογής",
	indirectSelectionCheckBox: "Γραμμή ${0}, πολλαπλές επιλογές, τετραγωνίδιο επιλογής",
	selectAll: "Επιλογή όλων"
})
//end v1.x content
);

