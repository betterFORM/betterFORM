define(
//begin v1.x content
({
	singleSort: "Enkeltsortering",
	nestedSort: "Nestet sortering",
	ascending: "Stigende",
	descending: "Synkende",
	sortingState: "${0} - ${1}",
	unsorted: "Ikke sorter denne kolonnen",
	indirectSelectionRadio: "Rad ${0}, enkeltvalg, valgknapp",
	indirectSelectionCheckBox: "Rad ${0}, flervalg, avmerkingsboks",
	selectAll: "Velg alle"
})
//end v1.x content
);

