define(
//begin v1.x content
({
	"descTemplate": "${2} - ${3} / ${1} ${0}",
	"firstTip": "首頁",
	"lastTip": "末頁",
	"nextTip": "下一頁",
	"prevTip": "上一頁",
	"itemTitle": "項目",
	"singularItemTitle": "項目",
	"pageStepLabelTemplate": "第 ${0} 頁",
	"pageSizeLabelTemplate": "每頁 ${0} 個項目",
	"allItemsLabelTemplate": "所有項目",
	"gotoButtonTitle": "跳至特定頁面",
	"dialogTitle": "跳至頁面",
	"dialogIndication": "指定頁碼",
	"pageCountIndication": "（${0} 頁）",
	"dialogConfirm": "執行",
	"dialogCancel": "取消",
	"all": "全部"
})
//end v1.x content
);

