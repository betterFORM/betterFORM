define(
//begin v1.x content
({
	singleSort: "Egyszerű rendezés",
	nestedSort: "Beágyazott rendezés",
	ascending: "Növekvő",
	descending: "Csökkenő",
	sortingState: "${0} - ${1}",
	unsorted: "Ne rendezze ezt az oszlopot",
	indirectSelectionRadio: "${0} sor, egyetlen kijelölés, választógomb",
	indirectSelectionCheckBox: "${0} sor, több kijelölés, jelölőnégyzet",
	selectAll: "Összes kijelölése"
})
//end v1.x content
);

