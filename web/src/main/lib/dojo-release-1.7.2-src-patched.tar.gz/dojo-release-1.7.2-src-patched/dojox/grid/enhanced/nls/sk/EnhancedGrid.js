define(
//begin v1.x content
({
	singleSort: "Jednoduché triedenie",
	nestedSort: "Vnorené triedenie",
	ascending: "Vzostupne",
	descending: "Zostupne",
	sortingState: "${0} - ${1}",
	unsorted: "Netriediť tento stĺpec",
	indirectSelectionRadio: "Riadok ${0}, jednoduchý výber, prepínač",
	indirectSelectionCheckBox: "Riadok ${0}, viacnásobný výber, začiarkavacie políčko",
	selectAll: "Vybrať všetko"
})
//end v1.x content
);

