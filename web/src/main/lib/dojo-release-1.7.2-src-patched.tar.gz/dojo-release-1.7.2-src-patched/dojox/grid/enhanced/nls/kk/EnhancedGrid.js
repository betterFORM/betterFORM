define(
//begin v1.x content
({
	singleSort: "Бір рет сұрыптау",
	nestedSort: "Кірістірілген сұрыптау",
	ascending: "Артуы бойынша",
	descending: "Кемуі бойынша",
	sortingState: "${0} - ${1}",
	unsorted: "Бұл бағанды сұрыптамау",
	indirectSelectionRadio: "${0}-жол, жалғыз элементті таңдау, бір түймешікті таңдау тақтасы",
	indirectSelectionCheckBox: "${0}-жол, бірнеше элементті таңдау, құсбелгі",
	selectAll: "Барлығын таңдау"
})
//end v1.x content
);

