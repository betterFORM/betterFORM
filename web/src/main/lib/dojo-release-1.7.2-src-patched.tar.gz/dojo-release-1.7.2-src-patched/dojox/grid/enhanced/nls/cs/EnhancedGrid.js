define(
//begin v1.x content
({
	singleSort: "Jednotlivé řazení",
	nestedSort: "Vnořené řazení",
	ascending: "Vzestupně",
	descending: "Sestupně",
	sortingState: "${0} - ${1}",
	unsorted: "Neřadit tento sloupec",
	indirectSelectionRadio: "Řádek ${0}, jednotlivý výběr, přepínač",
	indirectSelectionCheckBox: "Řádek ${0}, vícenásobný výběr, zaškrtávací políčko",
	selectAll: "Vybrat vše"
})
//end v1.x content
);

