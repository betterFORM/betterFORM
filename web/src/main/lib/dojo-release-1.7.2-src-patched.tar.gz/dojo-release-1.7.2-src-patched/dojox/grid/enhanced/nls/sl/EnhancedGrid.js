define(
//begin v1.x content
({
	singleSort: "Enostavno razvrščanje",
	nestedSort: "Ugnezdeno razvrščanje",
	ascending: "Naraščajoče",
	descending: "Padajoče",
	sortingState: "${0} - ${1}",
	unsorted: "Ne razvrščaj tega stolpca",
	indirectSelectionRadio: "Vrstica ${0}, izbira enega elementa, okence z izbirnim gumbom",
	indirectSelectionCheckBox: "Vrstica ${0}, izbira več elementov, okence s potrditvenimi polji",
	selectAll: "Izberi vse"
})
//end v1.x content
);

