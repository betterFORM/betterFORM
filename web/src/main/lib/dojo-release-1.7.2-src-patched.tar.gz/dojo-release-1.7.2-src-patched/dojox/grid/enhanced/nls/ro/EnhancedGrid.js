define(
//begin v1.x content
({
	singleSort: "Sortare singulară",
	nestedSort: "Sortare imbricată",
	ascending: "Crescător",
	descending: "Descrescător",
	sortingState: "${0} - ${1}",
	unsorted: "Nu se sortează această coloană",
	indirectSelectionRadio: "Rândul ${0}, selecţie singulară, casetă radio",
	indirectSelectionCheckBox: "Rândul ${0}, selecţie multiplă, casetă de bifare",
	selectAll: "Selectare tot"
})
//end v1.x content
);

