({
	singleSort: "Classificação Única",
	nestedSort: "Classificação Aninhada",
	ascending: "Crescente",
	descending: "Decrescente",
	sortingState: "${0} - ${1}",
	unsorted: "Não classificar esta coluna",
	indirectSelectionRadio: "Linha ${0}, seleção única, caixa de opção",
	indirectSelectionCheckBox: "Linha ${0}, seleção múltipla, caixa de seleção",
	selectAll: "Selecionar todos"
})

