﻿define(
//begin v1.x content
({
	"MINUTES": "%1 分",
	"Second": "秒",
	"Day of the Week": "曜日",
	"Sunday": "日曜日",
	"Monday": "月曜日",
	"ON": "オン",
	"OFF": "オフ"
})
//end v1.x content
);
