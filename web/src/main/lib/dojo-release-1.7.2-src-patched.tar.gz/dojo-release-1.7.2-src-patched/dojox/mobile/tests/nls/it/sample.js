﻿define(
//begin v1.x content
({
	"MINUTES": "%1 Minuto",
	"Second": "secondo",
	"Day of the Week": "giorno della settimana",
	"Sunday": "Domenica",
	"Monday": "Lunedì"
})
//end v1.x content
);
