dependencies = {
	layers: [
		{
			name: "../demos/mvcMobile/src.js",
			resourceName: "demos.mvcMobile.src",
			dependencies: [
				"demos.mvcMobile.src"
			]
		}
	],

	prefixes: [
		[ "dijit", "../dijit" ],
		[ "dojox", "../dojox" ],
		[ "demos", "../demos" ]
	]
}
