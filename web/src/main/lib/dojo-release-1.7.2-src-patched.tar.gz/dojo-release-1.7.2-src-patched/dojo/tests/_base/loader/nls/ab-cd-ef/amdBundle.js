define({
	amdBundle:"amdBundle-ab-cd-ef"
});
