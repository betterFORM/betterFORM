define("three", {
    name: "three"
});
