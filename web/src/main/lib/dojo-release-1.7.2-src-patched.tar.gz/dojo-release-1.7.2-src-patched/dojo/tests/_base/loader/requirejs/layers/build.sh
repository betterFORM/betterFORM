../../build/build.sh baseUrl=../.. name=require include=i18n,text,order, out=allplugins-require.js optimize=none
