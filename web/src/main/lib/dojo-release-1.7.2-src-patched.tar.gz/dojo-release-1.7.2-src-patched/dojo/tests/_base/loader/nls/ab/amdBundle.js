define({
	amdBundle:"amdBundle-ab"
});
