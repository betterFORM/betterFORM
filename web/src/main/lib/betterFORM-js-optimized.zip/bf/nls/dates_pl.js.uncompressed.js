define('bf/nls/dates_pl',{
'dijit/form/nls/ComboBox':{"previousMessage":"Poprzednie wybory","nextMessage":"Więcej wyborów"}
,
'dijit/form/nls/validate':{"rangeMessage":"Ta wartość jest spoza zakresu.","invalidMessage":"Wprowadzona wartość jest nieprawidłowa.","missingMessage":"Ta wartość jest wymagana."}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});