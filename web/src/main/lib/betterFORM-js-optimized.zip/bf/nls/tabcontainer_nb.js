require({cache:{
'dijit/nls/nb/loading':function(){
define(
"dijit/nls/nb/loading", //begin v1.x content
({
	loadingState: "Laster inn...",
	errorState: "Det oppsto en feil"
})
//end v1.x content
);

},
'dijit/nls/nb/common':function(){
define(
"dijit/nls/nb/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Avbryt",
	buttonSave: "Lagre",
	itemClose: "Lukk"
})
//end v1.x content
);

}}});
define("bf/nls/tabcontainer_nb", [], 1);
