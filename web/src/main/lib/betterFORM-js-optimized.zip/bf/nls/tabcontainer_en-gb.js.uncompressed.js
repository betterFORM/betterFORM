define('bf/nls/tabcontainer_en-gb',{
'dijit/nls/loading':{"loadingState":"Loading...","errorState":"Sorry, an error occurred"}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Cancel","buttonSave":"Save","itemClose":"Close"}
});