define('bf/nls/tabcontainer_pt-pt',{
'dijit/nls/loading':{"loadingState":"A carregar...","errorState":"Lamentamos, mas ocorreu um erro"}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Cancelar","buttonSave":"Guardar","itemClose":"Fechar"}
});