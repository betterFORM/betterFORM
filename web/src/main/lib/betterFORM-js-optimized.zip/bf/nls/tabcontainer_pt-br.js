require({cache:{
'dijit/nls/pt/loading':function(){
define(
"dijit/nls/pt/loading", //begin v1.x content
({
	loadingState: "Carregando...",
	errorState: "Desculpe, ocorreu um erro"
})
//end v1.x content
);

},
'dijit/nls/pt-br/loading':function(){
define('dijit/nls/pt-br/loading',{});
},
'dijit/nls/pt/common':function(){
define(
"dijit/nls/pt/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Cancelar",
	buttonSave: "Salvar",
	itemClose: "Fechar"
})
//end v1.x content
);

},
'dijit/nls/pt-br/common':function(){
define('dijit/nls/pt-br/common',{});
}}});
define("bf/nls/tabcontainer_pt-br", [], 1);
