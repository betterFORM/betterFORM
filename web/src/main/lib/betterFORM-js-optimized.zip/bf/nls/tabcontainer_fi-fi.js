require({cache:{
'dijit/nls/fi/loading':function(){
define(
"dijit/nls/fi/loading", //begin v1.x content
({
	loadingState: "Lataus on meneillään...",
	errorState: "On ilmennyt virhe."
})
//end v1.x content
);

},
'dijit/nls/fi-fi/loading':function(){
define('dijit/nls/fi-fi/loading',{});
},
'dijit/nls/fi/common':function(){
define(
"dijit/nls/fi/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Peruuta",
	buttonSave: "Tallenna",
	itemClose: "Sulje"
})
//end v1.x content
);

},
'dijit/nls/fi-fi/common':function(){
define('dijit/nls/fi-fi/common',{});
}}});
define("bf/nls/tabcontainer_fi-fi", [], 1);
