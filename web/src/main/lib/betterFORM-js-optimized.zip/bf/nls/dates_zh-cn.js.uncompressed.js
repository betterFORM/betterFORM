define('bf/nls/dates_zh-cn',{
'dijit/form/nls/ComboBox':{"previousMessage":"先前选项","nextMessage":"更多选项"}
,
'dijit/form/nls/validate':{"rangeMessage":"此值超出范围。","invalidMessage":"输入的值无效。","missingMessage":"该值是必需的。"}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});