require({cache:{
'dijit/form/nls/nl/ComboBox':function(){
define(
"dijit/form/nls/nl/ComboBox", //begin v1.x content
({
		previousMessage: "Eerdere opties",
		nextMessage: "Meer opties"
})
//end v1.x content
);

},
'dijit/form/nls/nl-nl/ComboBox':function(){
define('dijit/form/nls/nl-nl/ComboBox',{});
},
'dijit/form/nls/nl/validate':function(){
define(
"dijit/form/nls/nl/validate", //begin v1.x content
({
	invalidMessage: "De opgegeven waarde is ongeldig.",
	missingMessage: "Deze waarde is verplicht.",
	rangeMessage: "Deze waarde is niet toegestaan."
})
//end v1.x content
);

},
'dijit/form/nls/nl-nl/validate':function(){
define('dijit/form/nls/nl-nl/validate',{});
},
'bf/input/nls/nl/DropDownDate':function(){
define('bf/input/nls/nl/DropDownDate',{});
},
'bf/input/nls/nl-nl/DropDownDate':function(){
define('bf/input/nls/nl-nl/DropDownDate',{});
}}});
define("bf/nls/dates_nl-nl", [], 1);
