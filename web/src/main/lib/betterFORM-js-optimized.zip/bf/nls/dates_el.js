require({cache:{
'dijit/form/nls/el/ComboBox':function(){
define(
"dijit/form/nls/el/ComboBox", //begin v1.x content
({
		previousMessage: "Προηγούμενες επιλογές",
		nextMessage: "Περισσότερες επιλογές"
})
//end v1.x content
);

},
'dijit/form/nls/el/validate':function(){
define(
"dijit/form/nls/el/validate", //begin v1.x content
({
	invalidMessage: "Η τιμή που καταχωρήσατε δεν είναι έγκυρη.",
	missingMessage: "Η τιμή αυτή πρέπει απαραίτητα να καθοριστεί.",
	rangeMessage: "Η τιμή αυτή δεν ανήκει στο εύρος έγκυρων τιμών."
})
//end v1.x content
);

},
'bf/input/nls/el/DropDownDate':function(){
define('bf/input/nls/el/DropDownDate',{});
}}});
define("bf/nls/dates_el", [], 1);
