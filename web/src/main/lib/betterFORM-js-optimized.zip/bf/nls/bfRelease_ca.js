require({cache:{
'dijit/form/nls/ca/validate':function(){
define(
"dijit/form/nls/ca/validate", //begin v1.x content
({
	invalidMessage: "El valor introduït no és vàlid",
	missingMessage: "Aquest valor és necessari",
	rangeMessage: "Aquest valor és fora de l'interval"
})

//end v1.x content
);

},
'bf/input/nls/ca/DropDownDate':function(){
define('bf/input/nls/ca/DropDownDate',{});
},
'dijit/nls/ca/loading':function(){
define(
"dijit/nls/ca/loading", //begin v1.x content
({
	loadingState: "S'està carregant...",
	errorState: "Ens sap greu. S'ha produït un error."
})

//end v1.x content
);

},
'dojo/cldr/nls/ca/number':function(){
define(
"dojo/cldr/nls/ca/number", //begin v1.x content
{
	"group": ".",
	"percentSign": "%",
	"exponential": "E",
	"scientificFormat": "#E0",
	"percentFormat": "#,##0%",
	"list": ";",
	"infinity": "∞",
	"patternDigit": "#",
	"minusSign": "-",
	"decimal": ",",
	"nan": "NaN",
	"nativeZeroDigit": "0",
	"perMille": "‰",
	"decimalFormat": "#,##0.###",
	"currencyFormat": "#,##0.00 ¤",
	"plusSign": "+"
}
//end v1.x content
);
},
'dijit/form/nls/ca/ComboBox':function(){
define(
"dijit/form/nls/ca/ComboBox", //begin v1.x content
({
		previousMessage: "Opcions anteriors",
		nextMessage: "Més opcions"
})

//end v1.x content
);

},
'dijit/nls/ca/common':function(){
define(
"dijit/nls/ca/common", //begin v1.x content
({
	buttonOk: "D'acord",
	buttonCancel: "Cancel·la",
	buttonSave: "Desa",
	itemClose: "Tanca"
})

//end v1.x content
);

}}});
define("bf/nls/bfRelease_ca", [], 1);
