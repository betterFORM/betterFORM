define('bf/nls/dates_en-us',{
'dijit/form/nls/ComboBox':{"previousMessage":"Previous choices","nextMessage":"More choices"}
,
'dijit/form/nls/validate':{"rangeMessage":"This value is out of range.","invalidMessage":"The value entered is not valid.","missingMessage":"This value is required."}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});