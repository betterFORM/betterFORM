define('bf/nls/dates_fr-fr',{
'dijit/form/nls/ComboBox':{"previousMessage":"Choix précédents","nextMessage":"Plus de choix"}
,
'dijit/form/nls/validate':{"rangeMessage":"Cette valeur n'est pas comprise dans la plage autorisée.","invalidMessage":"La valeur indiquée n'est pas correcte.","missingMessage":"Cette valeur est requise."}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});