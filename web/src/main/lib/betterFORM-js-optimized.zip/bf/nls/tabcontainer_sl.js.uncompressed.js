define('bf/nls/tabcontainer_sl',{
'dijit/nls/loading':{"loadingState":"Nalaganje ...","errorState":"Oprostite, prišlo je do napake."}
,
'dijit/nls/common':{"buttonOk":"V redu","buttonCancel":"Prekliči","buttonSave":"Shrani","itemClose":"Zapri"}
});