define('bf/nls/dates_cs',{
'dijit/form/nls/ComboBox':{"previousMessage":"Předchozí volby","nextMessage":"Další volby"}
,
'dijit/form/nls/validate':{"rangeMessage":"Tato hodnota je mimo rozsah.","invalidMessage":"Zadaná hodnota není platná.","missingMessage":"Tato hodnota je vyžadována."}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});