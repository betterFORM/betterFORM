define('bf/nls/dates_fi-fi',{
'dijit/form/nls/ComboBox':{"previousMessage":"Edelliset valinnat","nextMessage":"Lisää valintoja"}
,
'dijit/form/nls/validate':{"rangeMessage":"Tämä arvo on sallitun alueen ulkopuolella.","invalidMessage":"Annettu arvo ei kelpaa.","missingMessage":"Tämä arvo on pakollinen."}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});