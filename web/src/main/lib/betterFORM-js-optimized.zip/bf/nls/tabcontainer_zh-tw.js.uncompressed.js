define('bf/nls/tabcontainer_zh-tw',{
'dijit/nls/loading':{"loadingState":"載入中...","errorState":"抱歉，發生錯誤"}
,
'dijit/nls/common':{"buttonOk":"確定","buttonCancel":"取消","buttonSave":"儲存","itemClose":"關閉"}
});