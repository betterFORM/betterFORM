require({cache:{
'dijit/form/nls/cs/ComboBox':function(){
define(
"dijit/form/nls/cs/ComboBox", //begin v1.x content
({
		previousMessage: "Předchozí volby",
		nextMessage: "Další volby"
})
//end v1.x content
);

},
'dijit/form/nls/cs/validate':function(){
define(
"dijit/form/nls/cs/validate", //begin v1.x content
({
	invalidMessage: "Zadaná hodnota není platná.",
	missingMessage: "Tato hodnota je vyžadována.",
	rangeMessage: "Tato hodnota je mimo rozsah."
})
//end v1.x content
);

},
'bf/input/nls/cs/DropDownDate':function(){
define('bf/input/nls/cs/DropDownDate',{});
}}});
define("bf/nls/dates_cs", [], 1);
