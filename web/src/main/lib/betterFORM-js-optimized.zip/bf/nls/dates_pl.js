require({cache:{
'dijit/form/nls/pl/ComboBox':function(){
define(
"dijit/form/nls/pl/ComboBox", //begin v1.x content
({
		previousMessage: "Poprzednie wybory",
		nextMessage: "Więcej wyborów"
})
//end v1.x content
);

},
'dijit/form/nls/pl/validate':function(){
define(
"dijit/form/nls/pl/validate", //begin v1.x content
({
	invalidMessage: "Wprowadzona wartość jest niepoprawna.",
	missingMessage: "Ta wartość jest wymagana.",
	rangeMessage: "Ta wartość jest spoza zakresu."
})
//end v1.x content
);

},
'bf/input/nls/pl/DropDownDate':function(){
define('bf/input/nls/pl/DropDownDate',{});
}}});
define("bf/nls/dates_pl", [], 1);
