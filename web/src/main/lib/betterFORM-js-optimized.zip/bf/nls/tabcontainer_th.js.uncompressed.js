define('bf/nls/tabcontainer_th',{
'dijit/nls/loading':{"loadingState":"กำลังโหลด...","errorState":"ขออภัย เกิดข้อผิดพลาด"}
,
'dijit/nls/common':{"buttonOk":"ตกลง","buttonCancel":"ยกเลิก","buttonSave":"บันทึก","itemClose":"ปิด"}
});