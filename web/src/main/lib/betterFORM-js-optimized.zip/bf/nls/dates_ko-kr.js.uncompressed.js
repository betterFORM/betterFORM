define('bf/nls/dates_ko-kr',{
'dijit/form/nls/ComboBox':{"previousMessage":"이전 선택사항","nextMessage":"기타 선택사항"}
,
'dijit/form/nls/validate':{"rangeMessage":"이 값은 범위를 벗어납니다.","invalidMessage":"입력된 값이 올바르지 않습니다.","missingMessage":"이 값은 필수입니다."}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});