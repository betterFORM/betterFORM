require({cache:{
'dijit/form/nls/sv/ComboBox':function(){
define(
"dijit/form/nls/sv/ComboBox", //begin v1.x content
({
		previousMessage: "Föregående alternativ",
		nextMessage: "Fler alternativ"
})
//end v1.x content
);

},
'dijit/form/nls/sv/validate':function(){
define(
"dijit/form/nls/sv/validate", //begin v1.x content
({
	invalidMessage: "Det angivna värdet är ogiltigt.",
	missingMessage: "Värdet är obligatoriskt.",
	rangeMessage: "Värdet är utanför intervallet."
})
//end v1.x content
);

},
'bf/input/nls/sv/DropDownDate':function(){
define('bf/input/nls/sv/DropDownDate',{});
}}});
define("bf/nls/dates_sv", [], 1);
