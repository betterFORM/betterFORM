define('bf/nls/tabcontainer_hu',{
'dijit/nls/loading':{"loadingState":"Betöltés...","errorState":"Sajnálom, hiba történt"}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Mégse","buttonSave":"Mentés","itemClose":"Bezárás"}
});