require({cache:{
'dijit/form/nls/da/ComboBox':function(){
define(
"dijit/form/nls/da/ComboBox", //begin v1.x content
({
		previousMessage: "Forrige valg",
		nextMessage: "Flere valg"
})
//end v1.x content
);

},
'dijit/form/nls/da/validate':function(){
define(
"dijit/form/nls/da/validate", //begin v1.x content
({
	invalidMessage: "Den angivne værdi er ikke gyldig.",
	missingMessage: "Værdien er påkrævet.",
	rangeMessage: "Værdien er uden for intervallet."
})
//end v1.x content
);

},
'bf/input/nls/da/DropDownDate':function(){
define('bf/input/nls/da/DropDownDate',{});
}}});
define("bf/nls/dates_da", [], 1);
