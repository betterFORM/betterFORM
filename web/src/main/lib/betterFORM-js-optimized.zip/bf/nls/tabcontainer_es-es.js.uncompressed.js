define('bf/nls/tabcontainer_es-es',{
'dijit/nls/loading':{"loadingState":"Cargando...","errorState":"Lo siento, se ha producido un error"}
,
'dijit/nls/common':{"buttonOk":"Aceptar","buttonCancel":"Cancelar","buttonSave":"Guardar","itemClose":"Cerrar"}
});