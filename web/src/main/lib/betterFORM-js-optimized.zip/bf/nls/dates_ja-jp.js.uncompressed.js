define('bf/nls/dates_ja-jp',{
'dijit/form/nls/ComboBox':{"previousMessage":"以前の選択項目","nextMessage":"追加の選択項目"}
,
'dijit/form/nls/validate':{"rangeMessage":"この値は範囲外です。","invalidMessage":"入力した値は無効です。","missingMessage":"この値は必須です。"}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});