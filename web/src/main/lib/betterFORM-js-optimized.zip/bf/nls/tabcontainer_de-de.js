require({cache:{
'dijit/nls/de/loading':function(){
define(
"dijit/nls/de/loading", //begin v1.x content
({
	loadingState: "Wird geladen...",
	errorState: "Es ist ein Fehler aufgetreten."
})
//end v1.x content
);

},
'dijit/nls/de-de/loading':function(){
define('dijit/nls/de-de/loading',{});
},
'dijit/nls/de/common':function(){
define(
"dijit/nls/de/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Abbrechen",
	buttonSave: "Speichern",
	itemClose: "Schließen"
})
//end v1.x content
);

},
'dijit/nls/de-de/common':function(){
define('dijit/nls/de-de/common',{});
}}});
define("bf/nls/tabcontainer_de-de", [], 1);
