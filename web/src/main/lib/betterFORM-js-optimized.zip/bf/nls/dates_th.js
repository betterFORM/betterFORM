require({cache:{
'dijit/form/nls/th/ComboBox':function(){
define(
"dijit/form/nls/th/ComboBox", //begin v1.x content
({
		previousMessage: "การเลือกก่อนหน้า",
		nextMessage: "การเลือกเพิ่มเติม"
})

//end v1.x content
);

},
'dijit/form/nls/th/validate':function(){
define(
"dijit/form/nls/th/validate", //begin v1.x content
({
	invalidMessage: "ค่าที่ป้อนไม่ถูกต้อง",
	missingMessage: "จำเป็นต้องมีค่านี้",
	rangeMessage: "ค่านี้เกินช่วง"
})

//end v1.x content
);

},
'bf/input/nls/th/DropDownDate':function(){
define('bf/input/nls/th/DropDownDate',{});
}}});
define("bf/nls/dates_th", [], 1);
