require({cache:{
'dijit/form/nls/en/validate':function(){
define('dijit/form/nls/en/validate',{});
},
'dijit/form/nls/en-us/validate':function(){
define('dijit/form/nls/en-us/validate',{});
},
'bf/input/nls/en/DropDownDate':function(){
define('bf/input/nls/en/DropDownDate',{});
},
'bf/input/nls/en-us/DropDownDate':function(){
define('bf/input/nls/en-us/DropDownDate',{});
},
'dijit/nls/en/loading':function(){
define('dijit/nls/en/loading',{});
},
'dijit/nls/en-us/loading':function(){
define('dijit/nls/en-us/loading',{});
},
'dojo/cldr/nls/en/number':function(){
define(
"dojo/cldr/nls/en/number", //begin v1.x content
{
	"group": ",",
	"percentSign": "%",
	"exponential": "E",
	"scientificFormat": "#E0",
	"percentFormat": "#,##0%",
	"list": ";",
	"infinity": "∞",
	"patternDigit": "#",
	"minusSign": "-",
	"decimal": ".",
	"nan": "NaN",
	"nativeZeroDigit": "0",
	"perMille": "‰",
	"decimalFormat": "#,##0.###",
	"currencyFormat": "¤#,##0.00;(¤#,##0.00)",
	"plusSign": "+",
	"decimalFormat-short": "000T"
}
//end v1.x content
);
},
'dojo/cldr/nls/en-us/number':function(){
define('dojo/cldr/nls/en-us/number',{});
},
'dijit/form/nls/en/ComboBox':function(){
define('dijit/form/nls/en/ComboBox',{});
},
'dijit/form/nls/en-us/ComboBox':function(){
define('dijit/form/nls/en-us/ComboBox',{});
},
'dijit/nls/en/common':function(){
define('dijit/nls/en/common',{});
},
'dijit/nls/en-us/common':function(){
define('dijit/nls/en-us/common',{});
}}});
define("bf/nls/bfRelease_en-us", [], 1);
