define('bf/nls/dates_nb',{
'dijit/form/nls/ComboBox':{"previousMessage":"Tidligere valg","nextMessage":"Flere valg"}
,
'dijit/form/nls/validate':{"rangeMessage":"Denne verdien er utenfor gyldig område.","invalidMessage":"Den angitte verdien er ikke gyldig.","missingMessage":"Denne verdien er obligatorisk."}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});