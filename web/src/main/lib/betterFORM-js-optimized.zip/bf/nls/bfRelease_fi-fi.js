require({cache:{
'dijit/form/nls/fi/validate':function(){
define(
"dijit/form/nls/fi/validate", //begin v1.x content
({
	invalidMessage: "Annettu arvo ei kelpaa.",
	missingMessage: "Tämä arvo on pakollinen.",
	rangeMessage: "Tämä arvo on sallitun alueen ulkopuolella."
})
//end v1.x content
);

},
'dijit/form/nls/fi-fi/validate':function(){
define('dijit/form/nls/fi-fi/validate',{});
},
'bf/input/nls/fi/DropDownDate':function(){
define('bf/input/nls/fi/DropDownDate',{});
},
'bf/input/nls/fi-fi/DropDownDate':function(){
define('bf/input/nls/fi-fi/DropDownDate',{});
},
'dijit/nls/fi/loading':function(){
define(
"dijit/nls/fi/loading", //begin v1.x content
({
	loadingState: "Lataus on meneillään...",
	errorState: "On ilmennyt virhe."
})
//end v1.x content
);

},
'dijit/nls/fi-fi/loading':function(){
define('dijit/nls/fi-fi/loading',{});
},
'dojo/cldr/nls/fi/number':function(){
define(
"dojo/cldr/nls/fi/number", //begin v1.x content
{
	"group": " ",
	"percentSign": "%",
	"exponential": "E",
	"scientificFormat": "#E0",
	"percentFormat": "#,##0 %",
	"list": ";",
	"infinity": "∞",
	"patternDigit": "#",
	"minusSign": "-",
	"decimal": ",",
	"nan": "epäluku",
	"nativeZeroDigit": "0",
	"perMille": "‰",
	"decimalFormat": "#,##0.###",
	"currencyFormat": "#,##0.00 ¤",
	"plusSign": "+"
}
//end v1.x content
);
},
'dojo/cldr/nls/fi-fi/number':function(){
define('dojo/cldr/nls/fi-fi/number',{});
},
'dijit/form/nls/fi/ComboBox':function(){
define(
"dijit/form/nls/fi/ComboBox", //begin v1.x content
({
		previousMessage: "Edelliset valinnat",
		nextMessage: "Lisää valintoja"
})
//end v1.x content
);

},
'dijit/form/nls/fi-fi/ComboBox':function(){
define('dijit/form/nls/fi-fi/ComboBox',{});
},
'dijit/nls/fi/common':function(){
define(
"dijit/nls/fi/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Peruuta",
	buttonSave: "Tallenna",
	itemClose: "Sulje"
})
//end v1.x content
);

},
'dijit/nls/fi-fi/common':function(){
define('dijit/nls/fi-fi/common',{});
}}});
define("bf/nls/bfRelease_fi-fi", [], 1);
