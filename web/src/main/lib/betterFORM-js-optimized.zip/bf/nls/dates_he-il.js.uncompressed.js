define('bf/nls/dates_he-il',{
'dijit/form/nls/ComboBox':{"previousMessage":"האפשרויות הקודמות","nextMessage":"אפשרויות נוספות"}
,
'dijit/form/nls/validate':{"rangeMessage":"הערך מחוץ לטווח.","invalidMessage":"הערך שצוין אינו חוקי.","missingMessage":"זהו ערך דרוש."}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});