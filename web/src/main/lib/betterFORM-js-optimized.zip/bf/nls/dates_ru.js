require({cache:{
'dijit/form/nls/ru/ComboBox':function(){
define(
"dijit/form/nls/ru/ComboBox", //begin v1.x content
({
		previousMessage: "Предыдущие варианты",
		nextMessage: "Следующие варианты"
})
//end v1.x content
);

},
'dijit/form/nls/ru/validate':function(){
define(
"dijit/form/nls/ru/validate", //begin v1.x content
({
	invalidMessage: "Указано недопустимое значение.",
	missingMessage: "Это обязательное значение.",
	rangeMessage: "Это значение вне диапазона."
})
//end v1.x content
);

},
'bf/input/nls/ru/DropDownDate':function(){
define('bf/input/nls/ru/DropDownDate',{});
}}});
define("bf/nls/dates_ru", [], 1);
