define('bf/nls/dates_sk',{
'dijit/form/nls/ComboBox':{"previousMessage":"Predchádzajúce možnosti","nextMessage":"Viac možností"}
,
'dijit/form/nls/validate':{"rangeMessage":"Táto hodnota je mimo rozsah.","invalidMessage":"Zadaná hodnota nie je platná.","missingMessage":"Táto hodnota je povinná."}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});