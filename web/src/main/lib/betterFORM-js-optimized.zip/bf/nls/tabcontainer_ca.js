require({cache:{
'dijit/nls/ca/loading':function(){
define(
"dijit/nls/ca/loading", //begin v1.x content
({
	loadingState: "S'està carregant...",
	errorState: "Ens sap greu. S'ha produït un error."
})

//end v1.x content
);

},
'dijit/nls/ca/common':function(){
define(
"dijit/nls/ca/common", //begin v1.x content
({
	buttonOk: "D'acord",
	buttonCancel: "Cancel·la",
	buttonSave: "Desa",
	itemClose: "Tanca"
})

//end v1.x content
);

}}});
define("bf/nls/tabcontainer_ca", [], 1);
