define('bf/nls/dates_th',{
'dijit/form/nls/ComboBox':{"previousMessage":"การเลือกก่อนหน้า","nextMessage":"การเลือกเพิ่มเติม"}
,
'dijit/form/nls/validate':{"rangeMessage":"ค่านี้เกินช่วง","invalidMessage":"ค่าที่ป้อนไม่ถูกต้อง","missingMessage":"จำเป็นต้องมีค่านี้"}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});