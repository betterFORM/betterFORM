({
	createLinkTitle: "Linkin ominaisuudet",
	insertImageTitle: "Kuvan ominaisuudet",
	url: "URL-osoite:",
	text: "Kuvaus:",
	set: "Aseta"
})
