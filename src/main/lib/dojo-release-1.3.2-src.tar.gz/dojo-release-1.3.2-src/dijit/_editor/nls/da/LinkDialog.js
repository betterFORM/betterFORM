({
	createLinkTitle: "Linkegenskaber",
	insertImageTitle: "Billedegenskaber",
	url: "URL:",
	text: "Beskrivelse:",
	set: "Definér"
})
