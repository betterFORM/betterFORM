({
	createLinkTitle: "Propriedades de Link",
	insertImageTitle: "Propriedades de Imagem",
	url: "URL:",
	text: "Descrição: ",
	set: "Definir"
})
