({
	createLinkTitle: "Propriétés du lien",
	insertImageTitle: "Propriétés de l'image",
	url: "URL :",
	text: "Description :",
	set: "Définir",
	currentWindow: "Fenêtre courante",
	parentWindow: "Fenêtre parente",
	topWindow: "Fenêtre de plus haut niveau",
	newWindow: "Nouvelle fenêtre"
})
